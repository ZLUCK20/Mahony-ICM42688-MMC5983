/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
#include "ti_msp_dl_config.h"
#include "main.h"
#include "stdio.h"
#include "string.h"
#include "usart.h"

uint8_t oled_buffer[32];

uint8_t KeyNum;
int16_t Speed;
int encoder_count;


unsigned char uart_data = 0;

//PID走直线
PID_TypeDef pid_straight;
int32_t pid_straight_out;
float straight_target=0;

//PID循迹
PID_TypeDef pid_tarck;
int32_t pid_track_out;
float track_target=0;

//PID转向
PID_TypeDef pid_turn;
int32_t pid_turn_out;
float turn_target=0;

/* 固定时间窗口测速 */
static unsigned long last_speed_time = 0;
#define SPEED_SAMPLE_MS 1000   /* 每100ms采样一次 */

char track[10];
int8_t run=0;

// NRF24L01
// uint8_t SendFlag;								
// uint8_t SendSuccessCount, SendFailedCount;		
// uint8_t ReceiveFlag;							
// uint8_t ReceiveSuccessCount, ReceiveFailedCount;


float pitch, roll, yaw;

uint16_t distVal = 0;

uint8_t Angle = 90;

int main(void)
{
    SYSCFG_DL_init();
    SysTick_Init();
    
    OLED_Init();
    Ultrasonic_Init();
    BNO08X_Init();

    delay_ms(2000);
    /* IMU 初始化 (ICM42688 + MMC5983 上电，读取 WHO_AM_I，配置工作模式) */
    IMU_Init();

    NRF24L01_Init();
   
    Stepmotor_Init(); 

    Servo_Init();

    /* Don't remove this! */
    Interrupt_Init(); 

    //使能串口3&DMA打印
    //NVIC_ClearPendingIRQ(UART_3_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_3_INST_INT_IRQN);
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);

    NVIC_ClearPendingIRQ(UART_2_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);

    //定时器1
    NVIC_ClearPendingIRQ(TIMER_Test_INST_INT_IRQN);
    NVIC_EnableIRQ(TIMER_Test_INST_INT_IRQN);
    
    //使能按键-编码器
    NVIC_EnableIRQ(GPIOA_INT_IRQn);
    NVIC_EnableIRQ(GPIOB_INT_IRQn);

    PID_Init(&pid_straight, 2, 0, 0.2, 0, 150);
    PID_Init(&pid_tarck, 7, 0, 1, 0, 200);
    PID_Init(&pid_turn, 10, 0.1, 2, 100, 300);
    
    // OLED_ShowString(0,0,(uint8_t *)"Pitch",8);
    // OLED_ShowString(0,1,(uint8_t *)" Roll",8);
    // OLED_ShowString(0,2,(uint8_t *)"  Yaw",8);
    //OLED_ShowString(0,3,(uint8_t *)"Speed:",8);
    // OLED_ShowString(0,4,(uint8_t *)"Target:",8);
    //OLED_ShowString(0,5,(uint8_t *)"Actual:",8);
    // OLED_ShowString(0,6,(uint8_t *)"   Out:",8);

    //OLED_ShowString(16*6,0,(uint8_t *)"Accel",8);

    // OLED_ShowString(0,0,(uint8_t *)" T:",8);
    // OLED_ShowString(0,1,(uint8_t *)"TX:",8);
    // OLED_ShowString(0,2,(uint8_t *)" R:",8); 
    // OLED_ShowString(0,3,(uint8_t *)"RX:",8);

    // NRF24L01_TxPacket[0] = 0x00;
	// NRF24L01_TxPacket[1] = 0x01;
	// NRF24L01_TxPacket[2] = 0x02;
	// NRF24L01_TxPacket[3] = 0x03;

    //测试步进电机
    // for(int i=0;i<300;i++)
	// {
	// 	Stepmotor_Move('x', 50);
	// 	delay_ms(1);
	// }

    while (1) 
    {    
        //蓝牙串口UART3测试
        // UART3_printfDMA("helloworld\n"); 


        //bno08x串口陀螺仪测试
        // sprintf((char *)oled_buffer, "%-6.1f", bno08x_data.pitch);
        // OLED_ShowString(5*8,0,oled_buffer,8);
        // sprintf((char *)oled_buffer, "%-6.1f", bno08x_data.roll);
        // OLED_ShowString(5*8,1,oled_buffer,8);
        // sprintf((char *)oled_buffer, "%-6.1f", bno08x_data.yaw);
        // OLED_ShowString(5*8,2,oled_buffer,8);

        // sprintf((char *)oled_buffer, "%6d", bno08x_data.ax);
        // OLED_ShowString(15*6,1,oled_buffer,8);
        // sprintf((char *)oled_buffer, "%6d", bno08x_data.ay);
        // OLED_ShowString(15*6,2,oled_buffer,8);
        // sprintf((char *)oled_buffer, "%6d", bno08x_data.az);
        // OLED_ShowString(15*6,3,oled_buffer,8);

        // UART3_printfDMA("%-6.1f,%-6.1f,%-6.1f\n",bno08x_data.pitch,
        // bno08x_data.roll, bno08x_data.yaw);


        //电机&编码器&按键测试
        // if (Speed < -999) Speed = -1000;
        // if (Speed > 999)  Speed = 1000;
        // Motor_SetSpeed(Speed, Speed);
        
        // sprintf((char *)oled_buffer, "%5d", Speed);
        // OLED_ShowString(40,3,oled_buffer,8);         
        // sprintf((char *)oled_buffer, "%4d", encoder_count);
        // OLED_ShowString(40,5,oled_buffer,8);

        /* 每100ms清一次 encoder_count，用于测速 */
        // if (tick_ms - last_speed_time >= 100)
        // {
            
            // encoder_count = 0;
        //     last_speed_time = tick_ms;
        // }


        //NRF24L01测试
        // if (KeyNum == 1)				
		// {			
		// 	NRF24L01_TxPacket[0] ++;
		// 	NRF24L01_TxPacket[1] ++;
		// 	NRF24L01_TxPacket[2] ++;
		// 	NRF24L01_TxPacket[3] ++;			
		// 	SendFlag = NRF24L01_Send();			
		// 	if (SendFlag == 1)			
		// 	{
		// 		SendSuccessCount ++;	
		// 	}
		// 	else						
		// 	{
		// 		SendFailedCount ++;		
		// 	}			
        //     sprintf((char *)oled_buffer, "%3d-%3d-%d",SendSuccessCount, SendFailedCount, SendFlag);
        //     OLED_ShowString(24, 0, oled_buffer, 8);
        //     sprintf((char *)oled_buffer, "%2x %2x %2x %2x",NRF24L01_TxPacket[0], NRF24L01_TxPacket[1], NRF24L01_TxPacket[2],NRF24L01_TxPacket[3]);
        //     OLED_ShowString(24, 1, oled_buffer, 8);
		// }
        // ReceiveFlag = NRF24L01_Receive();	
		// if (ReceiveFlag)				
		// {
		// 	if (ReceiveFlag == 1)		
		// 	{
		// 		ReceiveSuccessCount ++;	
		// 	}
		// 	else	
		// 	{
		// 		ReceiveFailedCount ++;	
		// 	}
            
        //     sprintf((char *)oled_buffer, "%3d-%3d-%d",ReceiveSuccessCount, ReceiveFailedCount, ReceiveFlag);
        //     OLED_ShowString(24, 2, oled_buffer, 8);
        //     sprintf((char *)oled_buffer, "%2x %2x %2x %2x",NRF24L01_RxPacket[0], NRF24L01_RxPacket[1], NRF24L01_RxPacket[2],NRF24L01_RxPacket[3]);
        //     OLED_ShowString(24, 3, oled_buffer, 8);
		// }
        
        
        //循迹测试
        // Tracking_ReadAll_String(track);
        // //Tracking_run(track);       
        // OLED_ShowString(0,7,(uint8_t *)track,8);


        //测试IMU
        // float p_deg = pitch, r_deg = roll, y_deg = yaw;  // 快照ISR最新弧度值
        // Get_Angle(&p_deg, &r_deg, &y_deg);               // 转角度，写回局部变量（不污染全局）
        // //UART3_printfDMA("%.3f, %.3f, %.3f\n", p_deg, r_deg, y_deg);
        // sprintf((char *)oled_buffer, "%-6.1f", p_deg);
        // OLED_ShowString(5*8,0,oled_buffer,8);
        // sprintf((char *)oled_buffer, "%-6.1f", r_deg);
        // OLED_ShowString(5*8,1,oled_buffer,8);
        // sprintf((char *)oled_buffer, "%-6.1f", y_deg);
        // OLED_ShowString(5*8,2,oled_buffer,8);
        

        /* ─── 超声波测距测试 ─────────────────────────────────────────────── */
        // distVal = Read_Ultrasonic();
        // sprintf((char *)oled_buffer, "%4u", distVal);
        // OLED_ShowString(6*8,0,oled_buffer,16);

        
        //舵机测试
        Servo_SetAngle2(Angle);
        sprintf((char *)oled_buffer, "%3d", Angle);
        OLED_ShowString(5*8,7,oled_buffer,8);


        //摄像头串口测试
        // uart2_send_char('aaaaaa');
        // sprintf((char *)oled_buffer, "%c", uart_data);
        // OLED_ShowString(5*8,7,oled_buffer,8);
      
       
    }
}


void UART_3_INST_IRQHandler(void)
{
    switch (DL_UART_getPendingInterrupt(UART_3_INST)) 
    {
        case DL_UART_IIDX_DMA_DONE_TX:
            UART3_DMADoneTxCallback();
            break;
        default:
            break;
    }
}

//串口的中断服务函数
void UART_2_INST_IRQHandler(void)
{
    //如果产生了串口中断
    switch( DL_UART_getPendingInterrupt(UART_2_INST) )
    {
        case DL_UART_IIDX_RX://如果是接收中断
            //将发送过来的数据保存在变量中
            uart_data = DL_UART_Main_receiveData(UART_2_INST);
            //将保存的数据再发送出去
            uart2_send_char(uart_data);
            break;

        default://其他的串口中断
            break;
    }
}

