#ifndef __ULTRASONIC_H
#define __ULTRASONIC_H

#include <stdint.h>
#include "ti_msp_dl_config.h"
#include "main.h"

/* 麦克拉伦：外设时钟频率定义 */
#define ULTRASONIC_TIMER_FREQ   1000000U    /* TIMG8 时钟频率 1MHz = 1us/tick */

/* 引脚定义：TRIG=PB21, ECHO=PB22 */
#define TRIG_PORT      SR04_PORT
#define TRIG_PIN       SR04_Trig_PIN
#define ECHO_PORT      SR04_PORT
#define ECHO_PIN       SR04_Echo_PIN

/* GPIO 操作宏 */
#define TRIG_HIGH()    DL_GPIO_setPins(TRIG_PORT, TRIG_PIN)
#define TRIG_LOW()     DL_GPIO_clearPins(TRIG_PORT, TRIG_PIN)
#define ECHO_READ()    ((DL_GPIO_readPins(ECHO_PORT, ECHO_PIN) & ECHO_PIN) ? 1 : 0)

/* 微秒延时宏（基于 CPU 时钟） */
#define Ultrasonic_DelayUs(us)   delay_cycles((CPUCLK_FREQ / 1000000U) * (us))

/* 距离范围定义 */
#define ULTRASONIC_MAX_CM        400     /* 最大量程 400cm */
#define ULTRASONIC_MIN_CM        2       /* 最小量程 2cm */
#define ULTRASONIC_TIMEOUT_US    30000   /* 30ms 超时 ≈ 5m 量程 */

/* 测量模式 */
typedef enum {
    ULTRASONIC_MODE_BLOCKING   = 0,   /* 阻塞模式：等待测量完成 */
    ULTRASONIC_MODE_NONBLOCK   = 1,   /* 非阻塞模式：启动后轮询获取结果 */
} Ultrasonic_Mode_t;

/* 非阻塞内部状态 */
typedef enum {
    ULTRASONIC_STATE_IDLE       = 0,   /* 空闲 */
    ULTRASONIC_STATE_WAIT_ECHO  = 1,   /* 等待 ECHO 上升沿 */
    ULTRASONIC_STATE_MEASURE    = 2,   /* 等待 ECHO 下降沿（测量脉冲宽度） */
} Ultrasonic_State_t;

/* 状态结构体 */
typedef struct {
    volatile uint8_t      busy;            /* 测量中标志 */
    volatile uint8_t      new_data;        /* 新数据可用标志 */
    volatile uint16_t     pulse_us;        /* ECHO 脉冲宽度 (us) */
    volatile uint16_t     distance_cm;     /* 距离 (cm) */
    volatile uint8_t      error;           /* 错误标志 */
    volatile uint32_t     start_tick;      /* 本次测量启动时的 tick_ms（用于超时） */
    volatile uint8_t      state;           /* 非阻塞内部状态机 */
} Ultrasonic_Data_t;

/* 外部声明 */
extern Ultrasonic_Data_t g_ultrasonic;

/* ─── 接口函数 ─────────────────────────────────────────────────────────────── */

/**
 * @brief   初始化超声波模块
 *          - 配置 TRIG 引脚（推挽输出，低电平）
 *          - 配置 ECHO 引脚（浮空输入）
 *          - 初始化 TIMG8 定时器为 1us 计数
 */
void Ultrasonic_Init(void);

/**
 * @brief   触发一次测距（阻塞模式）
 * @return  距离 (cm)，范围 2~400，超时返回 0
 */
uint16_t Ultrasonic_GetDistance(void);

/**
 * @brief   非阻塞模式：启动一次测量
 */
void Ultrasonic_StartMeasurement(void);

/**
 * @brief   非阻塞模式：检查测量是否完成
 * @retval  1 - 测量完成，可读取结果
 * @retval  0 - 测量中
 */
uint8_t Ultrasonic_IsReady(void);

/**
 * @brief   非阻塞模式：获取测量结果
 * @return  距离 (cm)，范围 2~400，超时返回 0
 */
uint16_t Ultrasonic_GetResult(void);

/**
 * @brief   获取原始脉冲宽度 (us)
 * @return  脉冲宽度 (us)
 */
uint16_t Ultrasonic_GetPulseUs(void);

#endif /* __ULTRASONIC_H */