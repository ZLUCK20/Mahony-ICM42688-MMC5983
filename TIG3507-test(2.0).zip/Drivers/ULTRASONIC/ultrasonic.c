/**
 * @file    ultrasonic.c
 * @brief   HC-SR04 超声波测距驱动
 * @note    MCU: MSPM0G3507
 *          - TRIG: PB21 (推挽输出)
 *          - ECHO: PB22 (浮空输入)
 *          - TIMG8: 1MHz 时钟 (1us/tick) 用于测量 ECHO 脉冲宽度
 *          - 采集 3 次取平均，间隔 20ms
 */

#include "ultrasonic.h"
#include "clock.h"     /* tick_ms, mspm0_delay_ms() */

/* 延时宏 */
#define delay_ms(ms)   mspm0_delay_ms(ms)

/* ─── 全局变量 ─────────────────────────────────────────────────────────────── */
Ultrasonic_Data_t g_ultrasonic = {0};

/* ─── 内部函数声明 ─────────────────────────────────────────────────────────── */
static uint16_t Ultrasonic_MeasureOnce(void);
static uint16_t Ultrasonic_PulseToCm(uint16_t pulse_us);

/* ─── 初始化 ───────────────────────────────────────────────────────────────── */
/**
 * @brief   初始化超声波模块
 *          - TIMG8 已在 SysConfig 中配置为 1MHz (1us/tick)
 *          - 设置定时器加载值防止溢出
 *          - TRIG 初始为低电平
 */
void Ultrasonic_Init(void)
{
    /* 停止定时器并清零 */
    DL_Timer_stopCounter(TIMER_ULTRASONIC_INST);
    DL_Timer_setTimerCount(TIMER_ULTRASONIC_INST, 0);

    /* 设置最大计数值：65535us ≈ 1128cm，远超 400cm 量程 */
    DL_Timer_setLoadValue(TIMER_ULTRASONIC_INST, 65535);

    /* 确保 TRIG 初始为低电平 */
    TRIG_LOW();

    /* 清除全局状态 */
    g_ultrasonic.busy      = 0;
    g_ultrasonic.new_data  = 0;
    g_ultrasonic.pulse_us  = 0;
    g_ultrasonic.distance_cm = 0;
    g_ultrasonic.error     = 0;
    g_ultrasonic.state     = ULTRASONIC_STATE_IDLE;
    g_ultrasonic.start_tick = 0;
}

/* ─── 脉冲宽度 → 距离转换 ──────────────────────────────────────────────────── */
/**
 * @brief   将 ECHO 脉冲宽度 (us) 转换为距离 (cm)
 * @param   pulse_us  脉冲宽度，单位微秒
 * @return  距离 (cm)，超出范围返回 0
 * @note    公式：距离(cm) = 脉冲宽度(us) / 58
 *          声速 340m/s，来回除以 2，单位换算：34300/2/1000000 ≈ 1/58
 */
static uint16_t Ultrasonic_PulseToCm(uint16_t pulse_us)
{
    uint16_t dist;

    /* 计算距离 (四舍五入) */
    dist = (pulse_us + 29) / 58;

    /* 范围限制 */
    if (dist > ULTRASONIC_MAX_CM)
        return 0;
    if (dist < ULTRASONIC_MIN_CM)
        return 0;

    return dist;
}

/* ─── 单次测量 ─────────────────────────────────────────────────────────────── */
/**
 * @brief   单次超声波测距
 * @return  距离 (cm)，超时或无效返回 0
 * @note     发 TRIG 脉冲 (20us) → 等待 ECHO 上升沿 → 测量脉冲宽度
 *           超时保护 30ms (ECHO 上升沿等待 + 高电平保持等待)
 */
static uint16_t Ultrasonic_MeasureOnce(void)
{
    uint16_t pulse_us = 0;
    uint32_t timeout  = 0;

    /* ─── 1. 发送 TRIG 脉冲 (≥10us) ─── */
    TRIG_HIGH();
    Ultrasonic_DelayUs(20);
    TRIG_LOW();

    /* ─── 2. 等待 ECHO 上升沿 (超时 30ms) ─── */
    timeout = 0;
    while (ECHO_READ() == 0)
    {
        Ultrasonic_DelayUs(10);
        timeout++;
        if (timeout > 3000)         /* 3000 * 10us = 30ms */
        {
            return 0;               /* 超时，无回波 */
        }
    }

    /* ─── 3. 启动定时器，开始测量 ECHO 脉冲宽度 ─── */
    DL_Timer_setTimerCount(TIMER_ULTRASONIC_INST, 0);
    DL_Timer_startCounter(TIMER_ULTRASONIC_INST);

    /* ─── 4. 等待 ECHO 下降沿 (超时 30ms ≈ 5m 量程) ─── */
    timeout = 0;
    while (ECHO_READ() == 1)
    {
        Ultrasonic_DelayUs(10);
        timeout++;
        if (timeout > 3000)         /* 3000 * 10us = 30ms */
        {
            DL_Timer_stopCounter(TIMER_ULTRASONIC_INST);
            return 0;               /* 超时，距离过远 */
        }
    }

    /* ─── 5. 停止定时器，读取脉冲宽度 ─── */
    DL_Timer_stopCounter(TIMER_ULTRASONIC_INST);
    pulse_us = DL_Timer_getTimerCount(TIMER_ULTRASONIC_INST);

    /* ─── 6. 转换为距离并返回 ─── */
    return Ultrasonic_PulseToCm(pulse_us);
}

/* ─── 阻塞模式测距 ──────────────────────────────────────────────────────────── */
/**
 * @brief   阻塞式测距，采集 3 次取平均
 * @return  距离 (cm)，范围 2~400，超时/无效返回 0
 * @note    总耗时约 60ms（3 次 × 20ms 间隔）
 */
uint16_t Ultrasonic_GetDistance(void)
{
    uint16_t sum = 0;
    uint16_t val;
    uint8_t  count = 0;
    uint8_t  i;

    /* 采集 3 次有效数据 */
    for (i = 0; i < 3; i++)
    {
        val = Ultrasonic_MeasureOnce();
        if (val > 0)
        {
            sum += val;
            count++;
        }

        /* 两次测量间隔 20ms (避免回声干扰) */
        if (i < 2)
            delay_ms(20);
    }

    /* 没有有效数据则返回 0 */
    if (count == 0)
        return 0;

    /* 返回平均值 */
    return sum / count;
}

/* ─── 非阻塞模式接口 ────────────────────────────────────────────────────────── */

/**
 * @brief   非阻塞模式：启动一次测量
 * @note    发送 TRIG 脉冲 → 等待 ECHO 上升沿 → 测量脉冲宽度
 *          调用后需频繁轮询 Ultrasonic_IsReady() 检查是否完成
 */
void Ultrasonic_StartMeasurement(void)
{
    /* 如果正在测量则忽略 */
    if (g_ultrasonic.busy)
        return;

    /* 记录启动时间（用于超时判断） */
    g_ultrasonic.start_tick = tick_ms;

    /* 初始化状态 */
    g_ultrasonic.busy     = 1;
    g_ultrasonic.new_data = 0;
    g_ultrasonic.error    = 0;
    g_ultrasonic.pulse_us = 0;
    g_ultrasonic.state    = ULTRASONIC_STATE_WAIT_ECHO;

    /* 发送 TRIG 脉冲 (≥10us 即可，用 20us 留余量) */
    TRIG_HIGH();
    Ultrasonic_DelayUs(20);
    TRIG_LOW();

    /* 启动定时器（1us/tick），清零 */
    DL_Timer_setTimerCount(TIMER_ULTRASONIC_INST, 0);
    DL_Timer_startCounter(TIMER_ULTRASONIC_INST);
}

/**
 * @brief   非阻塞模式：检查测量是否完成
 * @note     需要在主循环中频繁调用 (建议每 100us ~ 1ms 至少调用一次)
 * @retval   1 - 测量完成（成功/超时），可读取结果
 * @retval   0 - 等待中
 */
uint8_t Ultrasonic_IsReady(void)
{
    uint16_t pulse_us;

    if (!g_ultrasonic.busy)
        return 1;   /* 空闲或已完成 */

    /* ─── 超时检查（从启动开始 30ms） ─── */
    if (tick_ms - g_ultrasonic.start_tick >= 30)
    {
        DL_Timer_stopCounter(TIMER_ULTRASONIC_INST);
        g_ultrasonic.pulse_us    = 0;
        g_ultrasonic.distance_cm = 0;
        g_ultrasonic.error       = 1;
        g_ultrasonic.busy        = 0;
        g_ultrasonic.new_data    = 1;
        return 1;
    }

    /* ─── 状态机 ─── */
    switch (g_ultrasonic.state)
    {
    case ULTRASONIC_STATE_WAIT_ECHO:
        /* 等待 ECHO 上升沿 */
        if (ECHO_READ() == 1)
        {
            /* ECHO 已变高，清零定时器开始计时 */
            DL_Timer_setTimerCount(TIMER_ULTRASONIC_INST, 0);
            g_ultrasonic.state = ULTRASONIC_STATE_MEASURE;
        }
        break;

    case ULTRASONIC_STATE_MEASURE:
        /* 等待 ECHO 下降沿 */
        if (ECHO_READ() == 0)
        {
            /* 停止定时器，读取脉冲宽度 */
            DL_Timer_stopCounter(TIMER_ULTRASONIC_INST);
            pulse_us = DL_Timer_getTimerCount(TIMER_ULTRASONIC_INST);

            /* 保存结果 */
            g_ultrasonic.pulse_us    = pulse_us;
            g_ultrasonic.distance_cm = Ultrasonic_PulseToCm(pulse_us);
            g_ultrasonic.new_data    = 1;
            g_ultrasonic.busy        = 0;
            g_ultrasonic.state       = ULTRASONIC_STATE_IDLE;
            return 1;
        }
        break;

    default:
        break;
    }

    return 0;   /* 等待中 */
}

/**
 * @brief   非阻塞模式：获取测量结果
 * @return  距离 (cm)，超时返回 0
 */
uint16_t Ultrasonic_GetResult(void)
{
    g_ultrasonic.new_data = 0;
    return g_ultrasonic.distance_cm;
}

/**
 * @brief   获取原始脉冲宽度
 * @return  脉冲宽度 (us)
 */
uint16_t Ultrasonic_GetPulseUs(void)
{
    return g_ultrasonic.pulse_us;
}