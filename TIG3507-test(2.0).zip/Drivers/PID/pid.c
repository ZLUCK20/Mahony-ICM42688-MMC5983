#include "pid.h"

/**
  * @brief  初始化 PID 参数
  * @param  pid: PID 结构体指针
  * @param  Kp, Ki, Kd: PID 系数
  * @param  IntegLimit: 积分限幅
  * @param  OutLimit:  输出限幅
  */
void PID_Init(PID_TypeDef *pid,
              float Kp, float Ki, float Kd,
              float IntegLimit, float OutLimit)
{
    pid->Kp         = Kp;
    pid->Ki         = Ki;
    pid->Kd         = Kd;
    pid->IntegLimit = IntegLimit;
    pid->OutLimit   = OutLimit;

    PID_Reset(pid);
}

/**
  * @brief  位置式 PID 计算
  *         Output = Kp * e + Ki * ∫e dt + Kd * de/dt
  * @param  pid:    PID 结构体指针
  * @param  Target: 目标值
  * @param  Actual: 实际值（反馈）
  * @retval PID 输出
  */
float PID_Calc(PID_TypeDef *pid, float Target, float Actual)
{
    float Error, Derivative;

    /* 计算误差 */
    Error = Target - Actual;

    /* 积分项（带限幅防饱和） */
    pid->Integral += Error;
    if (pid->Integral >  pid->IntegLimit) pid->Integral =  pid->IntegLimit;
    if (pid->Integral < -pid->IntegLimit) pid->Integral = -pid->IntegLimit;

    /* 微分项 */
    Derivative = Error - pid->PrevError;

    /* PID 输出 */
    pid->Output = pid->Kp * Error
                + pid->Ki * pid->Integral
                + pid->Kd * Derivative;

    /* 输出限幅 */
    if (pid->Output >  pid->OutLimit) pid->Output =  pid->OutLimit;
    if (pid->Output < -pid->OutLimit) pid->Output = -pid->OutLimit;

    /* 保存当前误差供下次微分计算 */
    pid->PrevError = Error;

    return pid->Output;
}

/**
  * @brief  重置 PID 内部状态
  * @param  pid: PID 结构体指针
  */
void PID_Reset(PID_TypeDef *pid)
{
    pid->Integral  = 0.0f;
    pid->PrevError = 0.0f;
    pid->Output    = 0.0f;
}