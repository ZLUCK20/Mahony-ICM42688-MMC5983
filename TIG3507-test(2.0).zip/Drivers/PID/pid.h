#ifndef __PID_H
#define __PID_H

#include "main.h"

/* ─── PID 参数结构体 ─────────────────────────────────────────────────────── */
typedef struct
{
    /* PID 系数 */
    float Kp;
    float Ki;
    float Kd;

    /* 积分限幅 */
    float IntegLimit;   /* 积分项输出限幅（防止积分饱和） */
    float OutLimit;     /* PID 总输出限幅 */

    /* 内部状态 */
    float Integral;     /* 积分累积值 */
    float PrevError;    /* 上一次误差（用于微分项） */

    /* 输出 */
    float Output;       /* PID 计算结果 */
} PID_TypeDef;

/* ─── 函数声明 ───────────────────────────────────────────────────────────── */

/**
  * @brief  初始化 PID 参数
  * @param  pid: PID 结构体指针
  * @param  Kp, Ki, Kd: PID 系数
  * @param  IntegLimit: 积分限幅
  * @param  OutLimit:  输出限幅
  */
void PID_Init(PID_TypeDef *pid,
              float Kp, float Ki, float Kd,
              float IntegLimit, float OutLimit);

/**
  * @brief  位置式 PID 计算（适用于角速度环、角度环等）
  * @param  pid:    PID 结构体指针
  * @param  Target: 目标值
  * @param  Actual: 实际值（反馈）
  * @retval PID 输出
  */
float PID_Calc(PID_TypeDef *pid, float Target, float Actual);

/**
  * @brief  重置 PID 内部状态（积分归零，误差清零）
  * @param  pid: PID 结构体指针
  */
void PID_Reset(PID_TypeDef *pid);

#endif /* __PID_H */