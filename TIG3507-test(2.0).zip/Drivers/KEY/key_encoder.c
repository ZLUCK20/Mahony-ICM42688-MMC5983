#include "clock.h"
#include "ti_msp_dl_config.h"

extern uint8_t KeyNum;
extern int16_t Speed;
extern int encoder_count;
extern uint8_t Angle;

void GROUP1_IRQHandler(void)    //按键中断
{
	//读取 GPIOB 和 GPIOA 中已使能的中断状态
    uint32_t gpioB = DL_GPIO_getEnabledInterruptStatus(GPIOB, Encoder_A1_PIN | Encoder_A0_PIN
                                                         | Key_SW4_PIN | Key_SW5_PIN);
    uint32_t gpioA = DL_GPIO_getEnabledInterruptStatus(GPIOA, Key_SW6_PIN| Encoder_B0_PIN | Encoder_B1_PIN);
	
   if ((gpioB & Key_SW4_PIN) == Key_SW4_PIN) 
	{
        //B21
        KeyNum=1;
		Speed=0;
        DL_GPIO_clearInterruptStatus(GPIOB, Key_SW4_PIN);
    }

	if ((gpioB & Key_SW5_PIN) == Key_SW5_PIN) 
	{
        //B27
        KeyNum=2;
        Speed+=100;
        Angle+=10;
        DL_GPIO_setPins(Buzzer_PORT, Buzzer_Pin_PIN);
        DL_GPIO_clearInterruptStatus(GPIOB, Key_SW5_PIN);
    }

    if ((gpioA & Key_SW6_PIN) == Key_SW6_PIN) 
	{
        //A29
        KeyNum=3;
        Speed-=100;
        Angle-=10;
        DL_GPIO_clearPins(Buzzer_PORT, Buzzer_Pin_PIN);
        DL_GPIO_clearInterruptStatus(GPIOA, Key_SW6_PIN);
    }
    
    if ((gpioB & Encoder_A0_PIN) == Encoder_A0_PIN) 
    {             
        if (DL_GPIO_readPins(Encoder_A1_PORT, Encoder_A1_PIN) > 0)
        {
            encoder_count --;
        }
        else 
        {
            encoder_count ++;
        }
        DL_GPIO_clearInterruptStatus(GPIOB, Encoder_A0_PIN);
    }
    if ((gpioB & Encoder_A1_PIN) == Encoder_A1_PIN) 
    {
        if (DL_GPIO_readPins(Encoder_A0_PORT, Encoder_A0_PIN) > 0)
        {
           encoder_count --;
        }
        else 
        {
            encoder_count ++;
        }
        DL_GPIO_clearInterruptStatus(GPIOB, Encoder_A1_PIN);
    }
    
     if ((gpioA & Encoder_B0_PIN) == Encoder_B0_PIN) 
    {             
        if (DL_GPIO_readPins(Encoder_B1_PORT, Encoder_B1_PIN) > 0)
        {
            encoder_count --;
        }
        else 
        {
            encoder_count ++;
        }
        DL_GPIO_clearInterruptStatus(GPIOA, Encoder_B0_PIN);
    }
    if ((gpioA & Encoder_B1_PIN) == Encoder_B1_PIN) 
    {
        if (DL_GPIO_readPins(Encoder_B0_PORT, Encoder_B0_PIN) > 0)
        {
           encoder_count ++;
        }
        else 
        {
            encoder_count --;
        }
        DL_GPIO_clearInterruptStatus(GPIOA, Encoder_B1_PIN);
    }
   
}



