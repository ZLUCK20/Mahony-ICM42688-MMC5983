#ifndef ICM42688_H
#define ICM42688_H

#include <stdint.h>
#include "ti_msp_dl_config.h"
#include "main.h"

/*
 * ICM42688 6轴IMU驱动 (MSPM0 移植版)
 *
 * 移植说明：
 *   原 STM32F4 版本使用 HAL 库 (HAL_SPI_Transmit/TransmitReceive)，
 *   现移植为 MSPM0 DriverLib API (DL_SPI_transmitData8 / DL_SPI_receiveData8)。
 *
 *   GPIO 控制：使用 DL_GPIO_setPins / DL_GPIO_clearPins
 *   SPI 通信 ：使用 DL_SPI_transmitData8 / DL_SPI_receiveData8 逐字节交换
 *
 * 硬件配置 (SysConfig)：
 *   - SPI_IMU (SPI1)：SCLK=PA17, MOSI=PA18, MISO=PB21
 *   - GPIO_ICM42688：CS1=PA13, CS2=PB17
 *   请确保在 SysConfig 中已正确配置上述外设。
 */

/* ==================== CS 引脚控制 ==================== */
/* CS1 (PA13) — ICM42688 片选，与 MMC5983 风格一致 */
#define IMU_CS1_LOW()   DL_GPIO_clearPins(GPIO_ICM42688_CS1_PORT, GPIO_ICM42688_CS1_PIN)
#define IMU_CS1_HIGH()  DL_GPIO_setPins(GPIO_ICM42688_CS1_PORT, GPIO_ICM42688_CS1_PIN)


/* ==================== 函数声明 ==================== */

/* 基础 SPI 读写 */
uint8_t ICM42688_SPI_SwapByte(uint8_t Byte);
void Gyro_WriteReg(uint8_t reg, uint8_t value);
void Gyro_ReadReg(uint8_t reg, uint8_t *rx_data, uint8_t len);

/* 陀螺仪设备功能 */
uint8_t Icm_ReadWhoAmI(void);
void    Icm_SwitchBank(uint8_t bank);
void    Icm_Init(void);
void    Icm_ReadAccel(int16_t *ax, int16_t *ay, int16_t *az);
void    Icm_ReadGyro(int16_t *gx, int16_t *gy, int16_t *gz);

#endif /* ICM42688_H */