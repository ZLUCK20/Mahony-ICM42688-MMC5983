#include "mahony_filter.h"
#include <stdio.h>
#include <math.h>
#include "usart.h"

#define PERCENT 0   /* 磁力计修正权重 (0=关闭, 0.5=折中, 1=完全跟随磁力计) */

void IMU_Init(void)
{
    uint8_t id1 = 0;
    uint8_t id2 = 0;

    /* ICM42688 上电初始化 */
    id1 = Icm_ReadWhoAmI();
    printf("Gyro_WHO_AM_I = 0x%02X (expected: 0x47)\r\n", id1);
    Icm_Init();

    /* MMC5983 上电初始化 */
    id2 = Mag_ReadWhoAmI();
    printf("Mag_WHO_AM_I = 0x%02X (expected: 0x30)\r\n", id2);
    Mag_Init();
}

void Print_initialvalue(void)
{
    int16_t Ax_Init, Ay_Init, Az_Init, Wx_Init, Wy_Init, Wz_Init;
    float mx_Init, my_Init, mz_Init;

    Icm_ReadAccel(&Ax_Init, &Ay_Init, &Az_Init);
    Icm_ReadGyro(&Wx_Init, &Wy_Init, &Wz_Init);
    Mag_ReadCalibratedData(&mx_Init, &my_Init, &mz_Init);

    UART3_printfDMA("Accel: %6d %6d %6d | Gyro: %6d %6d %6d\r\n",
           Ax_Init, Ay_Init, Az_Init, Wx_Init, Wy_Init, Wz_Init);
    //UART3_printfDMA("Mag: %f %f %f\r\n", mx_Init, my_Init, mz_Init);
}

/* ==================== 四元数基本运算 ==================== */

/* 四元数乘法 */
Quaternion quat_mul(Quaternion q1, Quaternion q2)
{
    Quaternion res;
    res.w = q1.w*q2.w - q1.x*q2.x - q1.y*q2.y - q1.z*q2.z;
    res.x = q1.w*q2.x + q1.x*q2.w + q1.y*q2.z - q1.z*q2.y;
    res.y = q1.w*q2.y - q1.x*q2.z + q1.y*q2.w + q1.z*q2.x;
    res.z = q1.w*q2.z + q1.x*q2.y - q1.y*q2.x + q1.z*q2.w;
    return res;
}

/* 四元数共轭 */
Quaternion quat_conj(Quaternion q)
{
    Quaternion res = {q.w, -q.x, -q.y, -q.z};
    return res;
}

/* 四元数模长 */
float quat_norm(Quaternion q)
{
    return sqrtf(q.w*q.w + q.x*q.x + q.y*q.y + q.z*q.z);
}

/* 归一化 */
Quaternion quat_normalize(Quaternion q)
{
    float n = quat_norm(q);
    if (n < 1e-6f) return q;
    Quaternion res = {q.w/n, q.x/n, q.y/n, q.z/n};
    return res;
}

/* 用四元数旋转一个三维向量 (纯四元数方式) */
Vector3f quat_rotate(Quaternion q, Vector3f v)
{
    Quaternion p = {0.0f, v.x, v.y, v.z};
    Quaternion q_inv = quat_conj(q);       /* 单位四元数的逆 = 共轭 */
    Quaternion rotated = quat_mul(quat_mul(q, p), q_inv);
    Vector3f res = {rotated.x, rotated.y, rotated.z};
    return res;
}

/* ==================== 四元数微分方程 ==================== */
Quaternion quaternion_derivative(Quaternion q, Vector3f omega)
{
    Quaternion omega_q = {0.0f, omega.x, omega.y, omega.z};
    Quaternion dq = quat_mul(q, omega_q);
    dq.w *= 0.5f; dq.x *= 0.5f; dq.y *= 0.5f; dq.z *= 0.5f;
    return dq;
}

/* ==================== 四阶龙格-库塔 (RK4) ==================== */
Quaternion quaternion_rk4(Quaternion q, Vector3f omega, float dt)
{
    Quaternion k1, k2, k3, k4;
    Quaternion q_tmp;
    float half_dt = 0.5f * dt;

    /* k1 = f(q, omega) */
    k1 = quaternion_derivative(q, omega);

    /* k2 = f(q + 0.5*dt*k1, omega) */
    q_tmp.w = q.w + half_dt * k1.w;
    q_tmp.x = q.x + half_dt * k1.x;
    q_tmp.y = q.y + half_dt * k1.y;
    q_tmp.z = q.z + half_dt * k1.z;
    k2 = quaternion_derivative(q_tmp, omega);

    /* k3 = f(q + 0.5*dt*k2, omega) */
    q_tmp.w = q.w + half_dt * k2.w;
    q_tmp.x = q.x + half_dt * k2.x;
    q_tmp.y = q.y + half_dt * k2.y;
    q_tmp.z = q.z + half_dt * k2.z;
    k3 = quaternion_derivative(q_tmp, omega);

    /* k4 = f(q + dt*k3, omega) */
    q_tmp.w = q.w + dt * k3.w;
    q_tmp.x = q.x + dt * k3.x;
    q_tmp.y = q.y + dt * k3.y;
    q_tmp.z = q.z + dt * k3.z;
    k4 = quaternion_derivative(q_tmp, omega);

    /* q_new = q + dt/6 * (k1 + 2*k2 + 2*k3 + k4) */
    Quaternion q_new;
    q_new.w = q.w + dt/6.0f * (k1.w + 2.0f*k2.w + 2.0f*k3.w + k4.w);
    q_new.x = q.x + dt/6.0f * (k1.x + 2.0f*k2.x + 2.0f*k3.x + k4.x);
    q_new.y = q.y + dt/6.0f * (k1.y + 2.0f*k2.y + 2.0f*k3.y + k4.y);
    q_new.z = q.z + dt/6.0f * (k1.z + 2.0f*k2.z + 2.0f*k3.z + k4.z);
    q_new = quat_normalize(q_new);
    return q_new;
}

/* ==================== 四元数转欧拉角 (NWU: 偏航-俯仰-滚转) ==================== */
void quaternion_to_euler(Quaternion q, float *roll, float *pitch, float *yaw)
{
    float yaw_val   = atan2f(2.0f*(q.w*q.z + q.x*q.y), 1.0f - 2.0f*(q.y*q.y + q.z*q.z));
    float pitch_val = 2.0f*(q.w*q.y - q.z*q.x);

    /* 钳位 asinf 参数在 [-1, 1] 范围内，防止浮点累积误差导致 NaN */
    if (pitch_val >  1.0f) pitch_val =  1.0f;
    if (pitch_val < -1.0f) pitch_val = -1.0f;

    float pitch_rad = asinf(pitch_val);
    float roll_val  = atan2f(2.0f*(q.w*q.x + q.y*q.z), 1.0f - 2.0f*(q.x*q.x + q.y*q.y));

    *yaw   = yaw_val;
    *pitch = pitch_rad;
    *roll  = roll_val;
}

/* ==================== Mahony 互补滤波 ==================== */
void Mahony_Filter(Quaternion q, Vector3f Gyro, Vector3f Accel, Vector3f Mag,
                   float dt, float Kp, float Ki,
                   Vector3f *e_int, Vector3f *omega_corrected)
{
    /* 加速度归一化 */
    float acc_norm = sqrtf(Accel.x * Accel.x + Accel.y * Accel.y + Accel.z * Accel.z);
    if (acc_norm > 1e-6f) {
        Accel.x /= acc_norm; Accel.y /= acc_norm; Accel.z /= acc_norm;
    }
    /* 磁力计归一化 (必须归一化，否则修正幅度随磁场强度变化) */
    float mag_norm = sqrtf(Mag.x * Mag.x + Mag.y * Mag.y + Mag.z * Mag.z);
    if (mag_norm > 1e-6f) {
        Mag.x /= mag_norm; Mag.y /= mag_norm; Mag.z /= mag_norm;
    }

    /* 加速度误差（叉积计算）*/
    Vector3f world_gravity = {0.0f, 0.0f, 1.0f};
    Vector3f v = quat_rotate(quat_conj(q), world_gravity); /* 世界系重力 → 载体系 */
    Vector3f e_acc;
    e_acc.x = Accel.y * v.z - Accel.z * v.y;
    e_acc.y = Accel.z * v.x - Accel.x * v.z;
    e_acc.z = Accel.x * v.y - Accel.y * v.x;

    /* 磁力计误差 (NWU: 北=X, 西=Y, 天=Z) */
    Vector3f h = quat_rotate(q, Mag);                      /* 载体系磁场 → 世界系 */
    float b = sqrtf(h.x*h.x + h.y*h.y);                    /* 水平投影强度 */
    Vector3f ref_mag_world = {b, 0.0f, h.z};               /* NWU 期望磁场: 水平全指北 */
    Vector3f w = quat_rotate(quat_conj(q), ref_mag_world); /* 期望磁场 → 载体系 */
    Vector3f e_mag;
    e_mag.x = Mag.y * w.z - Mag.z * w.y;
    e_mag.y = Mag.z * w.x - Mag.x * w.z;
    e_mag.z = Mag.x * w.y - Mag.y * w.x;

    /* 误差总和 */
    Vector3f e_total;
    e_total.x = e_acc.x + e_mag.x * PERCENT;
    e_total.y = e_acc.y + e_mag.y * PERCENT;
    e_total.z = e_acc.z + e_mag.z * PERCENT;

    /* 积分项累加 (消除陀螺仪常值零偏) */
    e_int->x += e_total.x * dt;
    e_int->y += e_total.y * dt;
    e_int->z += e_total.z * dt;

    /* 积分饱和限制 */
    #define MAHONY_INTEGRAL_LIMIT 10.0f
    if (e_int->x >  MAHONY_INTEGRAL_LIMIT) e_int->x =  MAHONY_INTEGRAL_LIMIT;
    if (e_int->x < -MAHONY_INTEGRAL_LIMIT) e_int->x = -MAHONY_INTEGRAL_LIMIT;
    if (e_int->y >  MAHONY_INTEGRAL_LIMIT) e_int->y =  MAHONY_INTEGRAL_LIMIT;
    if (e_int->y < -MAHONY_INTEGRAL_LIMIT) e_int->y = -MAHONY_INTEGRAL_LIMIT;
    if (e_int->z >  MAHONY_INTEGRAL_LIMIT) e_int->z =  MAHONY_INTEGRAL_LIMIT;
    if (e_int->z < -MAHONY_INTEGRAL_LIMIT) e_int->z = -MAHONY_INTEGRAL_LIMIT;

    omega_corrected->x = Gyro.x + Kp * e_total.x + Ki * e_int->x;
    omega_corrected->y = Gyro.y + Kp * e_total.y + Ki * e_int->y;
    omega_corrected->z = Gyro.z + Kp * e_total.z + Ki * e_int->z;
}

/* ==================== 弧度转角度 ==================== */
void Get_Angle(float *pitch, float *roll, float *yaw)
{
    float p = *pitch, r = *roll, y = *yaw;

    /* 检查 NaN */
    if (!(p == p)) p = 0.0f;
    if (!(r == r)) r = 0.0f;
    if (!(y == y)) y = 0.0f;

    /* 弧度 → 角度 (180/π ≈ 57.29578) */
    *pitch = p * 57.29578f;
    *roll  = r * 57.29578f;
    *yaw   = y * 57.29578f;
}