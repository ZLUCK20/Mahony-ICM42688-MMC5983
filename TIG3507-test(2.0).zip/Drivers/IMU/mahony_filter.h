#ifndef MAHONY_FILTER_H
#define MAHONY_FILTER_H

#include <stdint.h>
#include <math.h>
#include "icm42688.h"
#include "MMC5983.h"

/*
 * Mahony 互补滤波器 (MSPM0 移植版)
 *
 * 移植说明：
 *   原 STM32F4 版本包含 "stm32f4xx_hal.h" / "usart.h"，
 *   现移除 HAL 依赖，仅使用纯 C 数学运算。
 *
 *   printf 打印通过 MSPM0 UART 重定向实现（需在 main.c 或系统配置中完成）。
 */

typedef struct {
    float w, x, y, z;
} Quaternion;

typedef struct {
    float x, y, z;
} Vector3f;

/* IMU 初始化（ICM42688 + MMC5983 上电初始化并打印设备ID） */
void IMU_Init(void);
void Print_initialvalue(void);

/* ==================== 四元数基本运算 ==================== */
Quaternion quat_mul(Quaternion q1, Quaternion q2);             /* 四元数乘法 */
Quaternion quat_conj(Quaternion q);                            /* 四元数共轭 */
float      quat_norm(Quaternion q);                            /* 四元数模长 */
Quaternion quat_normalize(Quaternion q);                       /* 归一化 */
Vector3f   quat_rotate(Quaternion q, Vector3f v);              /* 四元数旋转向量 */
Quaternion quaternion_derivative(Quaternion q, Vector3f omega);/* 四元数微分 */

/* ==================== 四阶龙格-库塔 (RK4) ==================== */
Quaternion quaternion_rk4(Quaternion q, Vector3f omega, float dt);

/* ==================== 四元数转欧拉角 ==================== */
void quaternion_to_euler(Quaternion q, float *roll, float *pitch, float *yaw);

/* ==================== Mahony 互补滤波 ==================== */
void Mahony_Filter(Quaternion q, Vector3f Gyro, Vector3f Accel, Vector3f Mag,
                   float dt, float Kp, float Ki,
                   Vector3f *e_int, Vector3f *omega_corrected);

/* ==================== 弧度转角度 ==================== */
void Get_Angle(float *pitch, float *roll, float *yaw);

#endif /* MAHONY_FILTER_H */