#include "icm42688.h"

/* ==================== SPI 字节交换函数 ==================== */
/* SPI 是全双工：每发送 1 字节，同时收到 1 字节
   参考同项目 MMC5983.c 的写法：发 → 等 → 收 → 等 */
uint8_t ICM42688_SPI_SwapByte(uint8_t Byte)
{
    uint8_t data = 0;
    DL_SPI_transmitData8(SPI_IMU_INST, Byte);
    while (DL_SPI_isBusy(SPI_IMU_INST));
    data = DL_SPI_receiveData8(SPI_IMU_INST);
    while (DL_SPI_isBusy(SPI_IMU_INST));
    return data;
}

// 写单个寄存器
void Gyro_WriteReg(uint8_t reg, uint8_t value)
{
    IMU_CS1_LOW();
    ICM42688_SPI_SwapByte(reg & 0x7F);       // 发送写命令（同时丢弃收到的垃圾字节）
    ICM42688_SPI_SwapByte(value);             // 发送数据
    IMU_CS1_HIGH();
}

// 读单个寄存器(或连续读多个)
void Gyro_ReadReg(uint8_t reg, uint8_t *rx_data, uint8_t len)
{
    IMU_CS1_LOW();

    /* 发送读命令，同时丢弃收到的垃圾字节
       注意：SPI 全双工，发命令的同时芯片返回了 1 个垃圾字节，
       必须把它读出来扔掉，否则后面数据会错位 */
    ICM42688_SPI_SwapByte(reg | 0x80);

    /* 连续发送 len 个 dummy 字节，同时接收 len 个数据 */
    for (uint8_t i = 0; i < len; i++) {
        rx_data[i] = ICM42688_SPI_SwapByte(0x00);
    }

    IMU_CS1_HIGH();
}

// 读取 WHO_AM_I
uint8_t Icm_ReadWhoAmI(void)
{
    uint8_t whoami = 0;
    Gyro_ReadReg(0x75, &whoami, 1);   // 读取1字节
    return whoami;
}

// 切换 Bank（低3位有效）
void Icm_SwitchBank(uint8_t bank)
{
    Gyro_WriteReg(0x76, bank & 0x07);
}


void Icm_Init(void)
{
    //--- 1. 软复位 ---
    Gyro_WriteReg(0x11, 0x01);                // DEVICE_CONFIG: soft reset
    delay_ms(2);                              // 等待至少1ms（MSP延时）
    Icm_SwitchBank(0);
    
    //--- 2. 配置传感器参数 ---
    Gyro_WriteReg(0x50, 0x06);                // ACCEL_CONFIG0: ±16g, 1kHz
    Gyro_WriteReg(0x4F, 0x06);                // GYRO_CONFIG0: ±2000dps, 1kHz
    Gyro_WriteReg(0x64, 0x00);                // INT_CONFIG1: 强制要求

    //--- 3. 开启传感器 ---
    Gyro_WriteReg(0x4E, 0x0F);                // PWR_MGMT0: 低噪声模式

    delay_ms(50);                  // 等待传感器起振
}


void Icm_ReadAccel(int16_t *ax, int16_t *ay, int16_t *az)
{
    uint8_t buf[6];
    Gyro_ReadReg(0x1F, buf, 6);   // 连续读6字节

    *ax = (int16_t)((buf[0] << 8) | buf[1]);
    *ay = (int16_t)((buf[2] << 8) | buf[3]);
    *az = (int16_t)((buf[4] << 8) | buf[5]);
}

void Icm_ReadGyro(int16_t *gx, int16_t *gy, int16_t *gz)
{
    uint8_t buf[6];
    Gyro_ReadReg(0x25, buf, 6);   // 连续读6字节

    *gx = (int16_t)((buf[0] << 8) | buf[1]);
    *gy = (int16_t)((buf[2] << 8) | buf[3]);
    *gz = (int16_t)((buf[4] << 8) | buf[5]);
}