#include "MMC5983.h"

/* ==================== SPI 字节交换函数 ==================== */
/* SPI 是全双工：每发送 1 字节，同时收到 1 字节
   发 → 等（忙完） → 收 → 等（忙完）
   确保 RX 寄存器不会残留数据，防止数据错位 */
uint8_t MMC5983_SPI_SwapByte(uint8_t Byte)
{
    uint8_t data = 0;
    DL_SPI_transmitData8(SPI_IMU_INST, Byte);
    while (DL_SPI_isBusy(SPI_IMU_INST));
    data = DL_SPI_receiveData8(SPI_IMU_INST);
    while (DL_SPI_isBusy(SPI_IMU_INST));
    return data;
}

void Mag_WriteReg(uint8_t reg, uint8_t value)
{
    MAG_CS2_LOW();
    MMC5983_SPI_SwapByte(reg & 0x7F);   // 发命令，同时取走垃圾字节扔掉
    MMC5983_SPI_SwapByte(value);         // 发数据
    MAG_CS2_HIGH();
}

void Mag_ReadReg(uint8_t reg, uint8_t *rx_data, uint8_t len)
{
    MAG_CS2_LOW();

    // 发读命令，同时取走垃圾字节扔掉，清空 RX 寄存器
    MMC5983_SPI_SwapByte(reg | 0x80);

    // 发 len 个 dummy，每个 dummy 交换回一个真实数据
    for (uint8_t i = 0; i < len; i++) {
        rx_data[i] = MMC5983_SPI_SwapByte(0x00);
    }

    MAG_CS2_HIGH();
}

uint8_t Mag_ReadWhoAmI(void)
{
    uint8_t whoami = 0;
    Mag_ReadReg(MMC5983_WHOAMI, &whoami, 1);
    return whoami;
}

void Mag_SoftReset(void)
{
    Mag_WriteReg(MMC5983_CTRL1, MMC5983_CTRL1_SW_RST);
    delay_ms(15);         
}

uint8_t Mag_IsMeasurementDone(void)
{
    uint8_t status;
    Mag_ReadReg(MMC5983_STATUS, &status, 1);
    return (status & MMC5983_STATUS_MEAS_M_DONE) != 0;
}

void Mag_WaitForMeasurement(void)
{
    uint32_t timeout = 10000;
    while (!Mag_IsMeasurementDone() && timeout > 0) {
        timeout--;
    }
}

void Mag_Init(void)
{
    // 1. 软复位，等待 OTP 加载
    Mag_SoftReset();   // 内部已包含 delay_ms(15)

    // 2. CTRL1: BW=11 (800Hz带宽)
    Mag_WriteReg(MMC5983_CTRL1, 0x03);

    // 3. 手动执行 SET/RESET 消磁
    Mag_WriteReg(MMC5983_CTRL0, 0x08);
    delay_ms(1);
    Mag_WriteReg(MMC5983_CTRL0, 0x00);
    delay_ms(1);
    Mag_WriteReg(MMC5983_CTRL0, 0x10);
    delay_ms(1);

    // 4. 开启 Auto_SR (自动 SET/RESET)
    Mag_WriteReg(MMC5983_CTRL0, 0x20);

    // 5. 配置连续模式: 1kHz ODR, 每25次测量执行一次 SET
    Mag_WriteReg(MMC5983_CTRL2, 0x9F);
}

void Mag_ReadData(int32_t *mx, int32_t *my, int32_t *mz)
{
    uint8_t buf[7];
    uint32_t raw_x18, raw_y18, raw_z18;

    Mag_ReadReg(MMC5983_XOUT0, buf, 7);

    // 拼接 18 位无符号原始值
    raw_x18 = ((uint32_t)buf[0] << 10) | ((uint32_t)buf[1] << 2) | ((uint32_t)(buf[6] >> 6) & 0x03);
    raw_y18 = ((uint32_t)buf[2] << 10) | ((uint32_t)buf[3] << 2) | ((uint32_t)(buf[6] >> 4) & 0x03);
    raw_z18 = ((uint32_t)buf[4] << 10) | ((uint32_t)buf[5] << 2) | ((uint32_t)(buf[6] >> 2) & 0x03);

    // 转换为有符号（减去零点），Z 轴取反
    *mx = (int32_t)(raw_x18 - MMC5983_18BIT_ZERO);
    *my = (int32_t)(raw_y18 - MMC5983_18BIT_ZERO);
    *mz = -(int32_t)(raw_z18 - MMC5983_18BIT_ZERO);
}

void Mag_ApplyCalibration(float *mx, float *my, float *mz)
{
    *mx = ((*mx) - MAG_HARD_IRON_X) / MAG_SCALE_X;
    *my = ((*my) - MAG_HARD_IRON_Y) / MAG_SCALE_Y;
    *mz = ((*mz) - MAG_HARD_IRON_Z) / MAG_SCALE_Z;
}

void Mag_ReadCalibratedData(float *mx, float *my, float *mz)
{
    int32_t raw_x, raw_y, raw_z;
    Mag_ReadData(&raw_x, &raw_y, &raw_z);
    *mx = (float)raw_x;
    *my = (float)raw_y;
    *mz = (float)raw_z;
    Mag_ApplyCalibration(mx, my, mz);
}