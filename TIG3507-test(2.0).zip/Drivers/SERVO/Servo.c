/*
 * Servo.c - 舵机驱动 (MSPM0G3507)
 *
 * TIMG7 PWM 50Hz
 *   CCP0 -> PA26 (舵机1, Servo_SetAngle)
 *   CCP1 -> PA27 (舵机2, Servo_SetAngle2)
 * 脉宽 500~2500us 对应 0°~180°
 *
 * 注意: MSPM0 DriverLib 中 DL_TimerA_* 兼容 TIMA 和 TIMG
 */

#include "Servo.h"
#include "ti_msp_dl_config.h"

void Servo_Init(void)
{
    SYSCFG_DL_PWM_Servo_init();
}

void Servo_SetAngle1(float Angle)
{
    uint16_t pulse;

    pulse = (uint16_t)(500 + (Angle / 180.0f) * 2000.0f);

    DL_TimerA_setCaptureCompareValue(PWM_Servo_INST, pulse, DL_TIMER_CC_0_INDEX);
}

void Servo_SetAngle2(float Angle)
{
    uint16_t pulse;

    pulse = (uint16_t)(500 + (Angle / 180.0f) * 2000.0f);

    DL_TimerA_setCaptureCompareValue(PWM_Servo_INST, pulse, DL_TIMER_CC_1_INDEX);
}
