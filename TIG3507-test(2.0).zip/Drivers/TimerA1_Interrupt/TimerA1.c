#include "ti_msp_dl_config.h"
#include "main.h"
#include "mahony_filter.h"

#define GYRO_SENSITIVITY (2000.0f / 32768.0f)  // dps per LSB
#define DPS_TO_RADS (M_PI / 180.0f)            // dps → rad/s


int a=0;//定时中断测试变量
Quaternion q = {1.0f, 0.0f, 0.0f, 0.0f};  // 初始化为单位四元数
Vector3f e_int = {0.0f, 0.0f, 0.0f};  // 误差积分项
Vector3f gyro, acc, mag;               // 传感器数据
Vector3f omega_corrected;              // 纠正后的角速度

float Kp = 5.0f;   // Mahony 比例系数 5.0
float Ki = 0.3f; // Mahony 积分系数   0.3
float dt = 0.005f; // 采样时间 (s)，匹配 5ms 定时器

int16_t ax, ay, az, gx, gy, gz;
float mx, my, mz;
extern float pitch, roll, yaw;
float isr_time_us;       // ISR 耗时 (微秒)，供 main.c 打印
uint32_t isr_max_cycles; // ISR 最大周期数

float yaw_offset = 0.0f;              // 上电初始偏置
int yaw_offset_locked = 0;            // 偏置锁定标志
const int yaw_offset_samples = 1000;  // 锁定前采样数


//PID走直线
extern PID_TypeDef pid_straight;
extern int32_t pid_straight_out;
extern float straight_target;

//PID循迹
extern PID_TypeDef pid_tarck;
extern int32_t pid_track_out;
extern float track_target;

//PID转向
extern PID_TypeDef pid_turn;
extern int32_t pid_turn_out;
extern float turn_target;

extern int8_t run;
uint32_t count;



//定时器的中断服务函数 已配置为1毫秒的周期
void TIMER_Test_INST_IRQHandler(void)
{
    //如果产生了定时器中断
    switch( DL_TimerG_getPendingInterrupt(TIMER_Test_INST) )
    {
        case DL_TIMER_IIDX_LOAD:
        {
            //a++;//中断测试++
            // uint32_t t_start = DWT->CYCCNT;  // 记录起始时刻  /*四元数mahony算法运行时间测试语句*/

            // 1. 读取传感器原始值
            Icm_ReadAccel(&ax, &ay, &az);
            Icm_ReadGyro(&gx, &gy, &gz);
            Mag_ReadCalibratedData(&mx, &my, &mz);

            // 2. 单位转换（LSB → rad/s）+ 零偏消除（必须在滤波之前）
            gyro.x = (gx + 17) * GYRO_SENSITIVITY * DPS_TO_RADS;
            gyro.y = (gy + 15) * GYRO_SENSITIVITY * DPS_TO_RADS;
        
         
            gyro.z = (gz - 1) * GYRO_SENSITIVITY * DPS_TO_RADS;
      

            acc.x = (ax + 8);
            acc.y = (ay + 64);
            acc.z = (az - 182);

            mag.x = mx;
            mag.y = my;
            mag.z = mz;

            // 3. Mahony 滤波
            Mahony_Filter(q, gyro, acc, mag, dt, Kp, Ki, &e_int, &omega_corrected);

            //4. RK4 积分(函数最后重新自带归一化来消除模长偏移)
            q = quaternion_rk4(q, omega_corrected, dt);
            
            //四元数转欧拉角（输出弧度）
            quaternion_to_euler(q, &roll, &pitch, &yaw);

            // --- yaw 上电归零：前 yaw_offset_samples 次采样锁定偏置 ---
            if (!yaw_offset_locked) {
                static int sample_cnt = 0;
                if (sample_cnt < yaw_offset_samples) {
                    sample_cnt++;
                    if (sample_cnt == yaw_offset_samples) {
                        yaw_offset = yaw;            // 锁定当前绝对 yaw
                        yaw_offset_locked = 1;
                    }
                }
            }

            // 减去偏置，得到相对角度
            yaw -= yaw_offset;

            // 归一化到 [-π, π]
            while (yaw >  M_PI) yaw -= 2.0f * M_PI;
            while (yaw < -M_PI) yaw += 2.0f * M_PI;

            
            // float error1 = straight_target + bno08x_data.yaw;
            // if (error1 > 180.0f)  error1 -= 360.0f;
            // if (error1 < -180.0f) error1 += 360.0f;
            // pid_straight_out = (int32_t)PID_Calc(&pid_straight, 0, -error1);

            // float error2 = turn_target + bno08x_data.yaw;
            // if (error2 > 180.0f)  error2 -= 360.0f;
            // if (error2 < -180.0f) error2 += 360.0f;
            // pid_turn_out = (int32_t)PID_Calc(&pid_tarck, 0, -error2);

            // pid_track_out = (int32_t)PID_Calc(&pid_turn, turn_target, track_error);
            break;
        }

        default://其他的定时器中断
            break;
    }
}