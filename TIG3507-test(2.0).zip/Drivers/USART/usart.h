#ifndef _USART_H_
#define _USART_H_


#include <stdint.h>
#include <stdarg.h>
#include <stdio.h>
#include "string.h"
#include "ti_msp_dl_config.h"

#define UART_TX_BUF_SIZE 256 // UART发送缓冲区长度

extern volatile uint8_t UART3TxDMADone;
extern volatile uint8_t UART2RxDMADone;


/**
 * @brief UART3发送字符串
 * @note 使用阻塞方式
 * @param str 待发送字符串指针
 * @return 字符串长度
 */
int UART3_sendStr(const char* str);

/**
 * @brief UART3 printf
 * @param fmt 格式控制字符串与参数列表
 * @return 字符串长度(vsprintf返回值)
 */
int UART3_printf(char* fmt, ...);

/**
 * @brief UART3使用DMA方式发送字符串
 * @note 调用该函数时, 若上次UART DMA已传送完成, 则占用时间最短
 * @param str 待发送字符串指针
 * @param len 字符串长度
 */
void UART3_sendStrDMA(const char* str, uint16_t len);

/**
 * @brief UART3 printf (使用DMA方式)
 * @note 调用该函数时, 若上次UART DMA已传送完成, 则占用时间最短
 * @param fmt 格式控制字符串与参数列表
 */
void UART3_printfDMA(char* fmt, ...);

void UART3_DMADoneTxCallback(void);

void uart2_send_char(char ch);

//串口发送字符串
void uart2_send_string(char* str);

#endif /* #ifndef __USER_UART_H__ */