#include "usart.h"

volatile uint8_t UART3TxDMADone = 1; // UART3发送DMA完成标志

/**
 * @brief UART3发送字符串
 * @note 使用阻塞方式
 * @param str 待发送字符串指针
 * @return 字符串长度
 */
int UART3_sendStr(const char* str) {
    int cnt = 0;
    while (*str) {
        DL_UART_transmitDataBlocking(UART_3_INST, (uint8_t)*str);
        str++;
        cnt++;
    }
    return cnt;
}

/**
 * @brief UART3 printf
 * @param fmt 格式控制字符串与参数列表
 * @return 字符串长度(vsprintf返回值)
 */
int UART3_printf(char* fmt, ...) {
    static char buf[UART_TX_BUF_SIZE];
    int len;
    va_list args;
    va_start(args, fmt);
    len = vsprintf(buf, fmt, args);
    va_end(args);
    UART3_sendStr(buf);
    return len;
}

/**
 * @brief UART3使用DMA方式发送字符串
 * @note 调用该函数时, 若上次UART DMA已传送完成, 则占用时间最短
 * @param str 待发送字符串指针
 * @param len 字符串长度
 */
void UART3_sendStrDMA(const char* str, uint16_t len) {
    while (!UART3TxDMADone);
    UART3TxDMADone = 0;
    DL_DMA_setSrcAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)str);
    DL_DMA_setDestAddr(DMA, DMA_CH0_CHAN_ID, (uint32_t)(&UART_3_INST->TXDATA));
    DL_DMA_setTransferSize(DMA, DMA_CH0_CHAN_ID, len);
    DL_DMA_enableChannel(DMA, DMA_CH0_CHAN_ID);
}

/**
 * @brief UART3 printf (使用DMA方式)
 * @note 调用该函数时, 若上次UART DMA已传送完成, 则占用时间最短
 * @param fmt 格式控制字符串与参数列表
 */
void UART3_printfDMA(char* fmt, ...) {
    static char buf[UART_TX_BUF_SIZE];
    uint16_t len;
    va_list args;
    while (!UART3TxDMADone);
    va_start(args, fmt);
    len = (uint16_t)vsprintf(buf, fmt, args);
    va_end(args);
    UART3_sendStrDMA(buf, len);
}

// UART3 DMA Tx完成中断回调
void UART3_DMADoneTxCallback(void) {
    UART3TxDMADone = 1;
}



void uart2_send_char(char ch)
{
    //当串口0忙的时候等待，不忙的时候再发送传进来的字符
    while( DL_UART_isBusy(UART_2_INST) == true );
    //发送单个字符
    DL_UART_Main_transmitData(UART_2_INST, ch);
}
//串口发送字符串
void uart2_send_string(char* str)
{
    //当前字符串地址不在结尾 并且 字符串首地址不为空
    while(*str!=0&&str!=0)
    {
        //发送字符串首地址中的字符，并且在发送完成之后首地址自增
        uart2_send_char(*str++);
    }
}

// //UART2
// int fputc(int c, FILE* stream) //串口重定向
// { 
//     DL_UART_Main_transmitDataBlocking(UART_2_INST, c); 
//     return c; 
// } 
// // 重定向 fputs
// int fputs(const char* restrict s, FILE* restrict stream) 
// { 
//     uint16_t i, len; 
//     len = strlen(s); 
//     for (i = 0; i < len; i++) 
//     { 
//         DL_UART_Main_transmitDataBlocking(UART_2_INST, s[i]); 
//     } 
//     return len; 
// }