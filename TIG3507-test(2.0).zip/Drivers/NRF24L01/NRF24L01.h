#ifndef __NRF24L01_H
#define __NRF24L01_H

#include "ti_msp_dl_config.h"
#include "NRF24L01_Define.h"
#include "main.h"

/*
 * 使用说明：
 * 1. 在SysConfig中添加SPI外设，命名为"SPI_NRF24L01"
 *    配置：模式0(CPOL=0,CPHA=0)，全双工，速率≤5MHz
 * 2. 在SysConfig中添加GPIO外设，命名为"GPIO_NRF24L01"
 *    添加两个引脚：PIN_CE 和 PIN_CSN，设为输出
 * 3. 根据实际接线修改下方 CE/CSN 的端口和引脚宏定义
 * 4. 调用 NRF24L01_Init() 完成初始化
 */

/* ==================================================== */

/* CE 引脚控制：高电平使能收发模式，低电平待机/掉电 */
#define NRF24L01_CE(n)               ((n) ? \
    DL_GPIO_setPins(GPIO_NRF24L01_CE_PORT, GPIO_NRF24L01_CE_PIN) : \
    DL_GPIO_clearPins(GPIO_NRF24L01_CE_PORT, GPIO_NRF24L01_CE_PIN))

/* CSN 引脚控制：低电平选中NRF24L01开始SPI通信，高电平结束 */
#define NRF24L01_CSN(n)              ((n) ? \
    DL_GPIO_setPins(GPIO_NRF24L01_CSN_PORT, GPIO_NRF24L01_CSN_PIN) : \
    DL_GPIO_clearPins(GPIO_NRF24L01_CSN_PORT, GPIO_NRF24L01_CSN_PIN))

/* ==================================================== */

/* 默认数据包宽度（用户可按需修改）*/
#ifndef NRF24L01_TX_PACKET_WIDTH
#define NRF24L01_TX_PACKET_WIDTH    4
#endif

#ifndef NRF24L01_RX_PACKET_WIDTH
#define NRF24L01_RX_PACKET_WIDTH    4
#endif

/* 外部可调用全局数组 */
extern uint8_t NRF24L01_TxAddress[5];
extern uint8_t NRF24L01_TxPacket[NRF24L01_TX_PACKET_WIDTH];

extern uint8_t NRF24L01_RxAddress[5];
extern uint8_t NRF24L01_RxPacket[NRF24L01_RX_PACKET_WIDTH];

/* 函数声明 */

/* 底层SPI接口 */
uint8_t NRF24L01_SPI_SwapByte(uint8_t Byte);

/* 指令实现 */
uint8_t NRF24L01_ReadReg(uint8_t RegAddress);
void   NRF24L01_ReadRegs(uint8_t RegAddress, uint8_t *DataArray, uint8_t Count);
void   NRF24L01_WriteReg(uint8_t RegAddress, uint8_t Data);
void   NRF24L01_WriteRegs(uint8_t RegAddress, uint8_t *DataArray, uint8_t Count);
void   NRF24L01_ReadRxPayload(uint8_t *DataArray, uint8_t Count);
void   NRF24L01_WriteTxPayload(uint8_t *DataArray, uint8_t Count);
void   NRF24L01_FlushTx(void);
void   NRF24L01_FlushRx(void);
uint8_t NRF24L01_ReadStatus(void);

/* 功能函数 */
void   NRF24L01_PowerDown(void);
void   NRF24L01_StandbyI(void);
void   NRF24L01_Rx(void);
void   NRF24L01_Tx(void);

void   NRF24L01_Init(void);
uint8_t NRF24L01_Send(void);
uint8_t NRF24L01_Receive(void);
void   NRF24L01_UpdateRxAddress(void);

#endif