#include "NRF24L01.h"

/*
 * NRF24L01 无线模块驱动 (MSPM0 移植版)
 *
 * 移植说明：
 *   原 STM32F4 版本使用标准外设库 (SPI_I2S_SendData 等)，
 *   现移植为 MSPM0 DriverLib API (DL_SPI_transmitData8 等)。
 *
 *   GPIO 控制：使用 DL_GPIO_setPins / DL_GPIO_clearPins 宏
 *   SPI 通信 ：使用 DL_SPI_transmitData8 / DL_SPI_receiveData8
 *
 *   SPI_NRF24L01_INST 和 GPIO_NRF24L01_PORT/PIN 等由 SysConfig 生成
 *   在 ti_msp_dl_config.h 中定义，请确保 SysConfig 中已正确配置。
 */

/* ==================== 全局变量 ==================== */

uint8_t NRF24L01_TxAddress[5] = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE};
uint8_t NRF24L01_TxPacket[NRF24L01_TX_PACKET_WIDTH];

uint8_t NRF24L01_RxAddress[5] = {0xAA, 0xBB, 0xCC, 0xDD, 0xEE};
uint8_t NRF24L01_RxPacket[NRF24L01_RX_PACKET_WIDTH];

/* ==================== 通信协议 ==================== */

/**
  * 函    数：硬件SPI交换一个字节
  * 参    数：Byte - 要发送的字节数据
  * 返 回 值：接收到的字节数据
  * 说    明：MSPM0 使用 DL_SPI 库，发送和接收分别调用不同函数。
  *           发送后需等待 SPI 空闲，接收前需等待 SPI 空闲。
  */
uint8_t NRF24L01_SPI_SwapByte(uint8_t Byte)
{
    uint8_t data = 0;

    /* 发送数据 */
    DL_SPI_transmitData8(SPI_NRF24L01_INST, Byte);
    /* 等待SPI总线空闲 */
    while (DL_SPI_isBusy(SPI_NRF24L01_INST));
    /* 接收数据 */
    data = DL_SPI_receiveData8(SPI_NRF24L01_INST);
    /* 等待SPI总线空闲 */
    while (DL_SPI_isBusy(SPI_NRF24L01_INST));

    return data;
}

/* ==================== 指令实现 ==================== */

/**
  * 函    数：NRF24L01读取寄存器（一个字节）
  * 参    数：RegAddress 指定寄存器地址，范围：0x00~0x1F
  * 返 回 值：指定寄存器的数据，范围：0x00~0xFF
  */
uint8_t NRF24L01_ReadReg(uint8_t RegAddress)
{
    uint8_t Data;

    NRF24L01_CSN(0);                          // CSN拉低，选中NRF24L01，开始SPI通信事务

    /* 发送读寄存器指令：指令码 R_REGISTER | 寄存器地址 */
    NRF24L01_SPI_SwapByte(NRF24L01_R_REGISTER | RegAddress);

    /* 发送NOP空操作，同时接收寄存器的值 */
    Data = NRF24L01_SPI_SwapByte(NRF24L01_NOP);

    NRF24L01_CSN(1);                          // CSN拉高，结束本次SPI通信事务
    return Data;
}

/**
  * 函    数：NRF24L01读取寄存器（多个字节）
  * 参    数：RegAddress - 起始寄存器地址，范围：0x00~0x1F
  * 参    数：DataArray  - 存储读取结果的数组指针（输出参数）
  * 参    数：Count      - 要读取的字节数（寄存器数量）
  * 返 回 值：无
  */
void NRF24L01_ReadRegs(uint8_t RegAddress, uint8_t *DataArray, uint8_t Count)
{
    uint8_t i;

    NRF24L01_CSN(0);
    NRF24L01_SPI_SwapByte(NRF24L01_R_REGISTER | RegAddress);
    for (i = 0; i < Count; i++)
        DataArray[i] = NRF24L01_SPI_SwapByte(NRF24L01_NOP);
    NRF24L01_CSN(1);
}

/**
  * 函    数：NRF24L01写寄存器（一个字节）
  * 参    数：RegAddress 要写入的寄存器地址，范围：0x00~0x1F
  * 参    数：Data       要写入的一个字节数据，范围：0x00~0xFF
  * 返 回 值：无
  */
void NRF24L01_WriteReg(uint8_t RegAddress, uint8_t Data)
{
    NRF24L01_CSN(0);
    NRF24L01_SPI_SwapByte(NRF24L01_W_REGISTER | RegAddress);
    NRF24L01_SPI_SwapByte(Data);
    NRF24L01_CSN(1);
}

/**
  * 函    数：NRF24L01写寄存器（多个字节）
  * 参    数：RegAddress - 起始寄存器地址，范围：0x00~0x1F
  * 参    数：DataArray  - 要写入的数据数组指针（输入参数）
  * 参    数：Count      - 要写入的字节数
  * 返 回 值：无
  */
void NRF24L01_WriteRegs(uint8_t RegAddress, uint8_t *DataArray, uint8_t Count)
{
    uint8_t i;

    NRF24L01_CSN(0);
    NRF24L01_SPI_SwapByte(NRF24L01_W_REGISTER | RegAddress);
    for (i = 0; i < Count; i++)
        NRF24L01_SPI_SwapByte(DataArray[i]);
    NRF24L01_CSN(1);
}

/**
  * 函    数：NRF24L01读取Rx有效载荷（接收到的数据）
  * 参    数：DataArray - 存储读取数据的数组指针（输出参数）
  * 参    数：Count     - 要读取的字节数，范围：1~32
  * 返 回 值：无
  */
void NRF24L01_ReadRxPayload(uint8_t *DataArray, uint8_t Count)
{
    uint8_t i;

    NRF24L01_CSN(0);
    NRF24L01_SPI_SwapByte(NRF24L01_R_RX_PAYLOAD);
    for (i = 0; i < Count; i++)
        DataArray[i] = NRF24L01_SPI_SwapByte(NRF24L01_NOP);
    NRF24L01_CSN(1);
}

/**
  * 函    数：NRF24L01写入Tx有效载荷（待发送的数据）
  * 参    数：DataArray - 要写入的数据数组指针（输入参数）
  * 参    数：Count     - 要写入的字节数，范围：1~32
  * 返 回 值：无
  */
void NRF24L01_WriteTxPayload(uint8_t *DataArray, uint8_t Count)
{
    uint8_t i;

    NRF24L01_CSN(0);
    NRF24L01_SPI_SwapByte(NRF24L01_W_TX_PAYLOAD);
    for (i = 0; i < Count; i++)
        NRF24L01_SPI_SwapByte(DataArray[i]);
    NRF24L01_CSN(1);
}

/**
  * 函    数：清空发送FIFO缓冲区
  * 参    数：无
  * 返 回 值：无
  */
void NRF24L01_FlushTx(void)
{
    NRF24L01_CSN(0);
    NRF24L01_SPI_SwapByte(NRF24L01_FLUSH_TX);
    NRF24L01_CSN(1);
}

/**
  * 函    数：清空接收FIFO缓冲区
  * 参    数：无
  * 返 回 值：无
  */
void NRF24L01_FlushRx(void)
{
    NRF24L01_CSN(0);
    NRF24L01_SPI_SwapByte(NRF24L01_FLUSH_RX);
    NRF24L01_CSN(1);
}

/**
  * 函    数：读取NRF24L01的状态寄存器
  * 参    数：无
  * 返 回 值：状态寄存器的值（8位）
  * 说    明：发送NOP指令时，NRF24L01会在MISO线上返回状态寄存器的当前值
  */
uint8_t NRF24L01_ReadStatus(void)
{
    uint8_t Status;

    NRF24L01_CSN(0);
    Status = NRF24L01_SPI_SwapByte(NRF24L01_NOP);
    NRF24L01_CSN(1);
    return Status;
}

/* ==================== 功能函数 ==================== */

/**
  * 函    数：NRF24L01进入掉电模式（CE=0, PWR_UP=0）
  * 说    明：掉电模式下芯片功耗极低（约900nA），寄存器内容保持。
  */
void NRF24L01_PowerDown(void)
{
    uint8_t Config;

    NRF24L01_CE(0);
    Config = NRF24L01_ReadReg(NRF24L01_CONFIG);
    if (Config == 0xFF) return;             // 读取失败，可能设备未连接
    Config &= ~0x02;                        // 清除PWR_UP位
    NRF24L01_WriteReg(NRF24L01_CONFIG, Config);
}

/**
  * 函    数：NRF24L01进入待机模式1（CE=0, PWR_UP=1）
  * 说    明：待机模式1下芯片内部时钟稳定，可快速切换到收发模式。
  */
void NRF24L01_StandbyI(void)
{
    uint8_t Config;

    NRF24L01_CE(0);
    Config = NRF24L01_ReadReg(NRF24L01_CONFIG);
    if (Config == 0xFF) return;
    Config |= 0x02;                         // 设置PWR_UP位
    NRF24L01_WriteReg(NRF24L01_CONFIG, Config);
}

/**
  * 函    数：NRF24L01进入接收模式（CE=1, PWR_UP=1, PRIM_RX=1）
  * 说    明：启动接收器，监听空中信号。
  */
void NRF24L01_Rx(void)
{
    uint8_t Config;

    NRF24L01_CE(0);
    Config = NRF24L01_ReadReg(NRF24L01_CONFIG);
    if (Config == 0xFF) return;
    Config |= 0x03;                         // PWR_UP=1, PRIM_RX=1
    NRF24L01_WriteReg(NRF24L01_CONFIG, Config);
    NRF24L01_CE(1);                         // CE置高，进入接收模式
}

/**
  * 函    数：NRF24L01进入发送模式（CE=1, PWR_UP=1, PRIM_RX=0）
  * 说    明：启动发送器，将TX FIFO中的数据包发出。
  */
void NRF24L01_Tx(void)
{
    uint8_t Config;

    NRF24L01_CE(0);
    Config = NRF24L01_ReadReg(NRF24L01_CONFIG);
    if (Config == 0xFF) return;
    Config |= 0x02;                         // PWR_UP=1
    Config &= ~0x01;                        // PRIM_RX=0 (发送模式)
    NRF24L01_WriteReg(NRF24L01_CONFIG, Config);
    NRF24L01_CE(1);                         // CE置高，启动发送
}

/**
  * 函    数：NRF24L01初始化
  * 参    数：无
  * 返 回 值：无
  * 说    明：配置寄存器、清空FIFO、清除状态位，最后进入接收模式
  *
  * 注意：SPI外设和GPIO引脚的初始化由SysConfig自动生成，
  *       在 main() 中调用 SYSCFG_DL_init() 完成初始化。
  *       本函数只对 NRF24L01 芯片进行寄存器配置。
  */
void NRF24L01_Init(void)
{
    /* CE和CSN初始化为默认电平 */
    NRF24L01_CE(0);
    NRF24L01_CSN(1);

    /* NRF24L01芯片寄存器初始化 */
    NRF24L01_WriteReg(NRF24L01_CONFIG,     0x08);
    NRF24L01_WriteReg(NRF24L01_EN_AA,      0x3F);  // 使能全部通道自动应答
    NRF24L01_WriteReg(NRF24L01_EN_RXADDR,  0x01);  // 使能接收通道0
    NRF24L01_WriteReg(NRF24L01_SETUP_AW,   0x03);  // 地址宽度5字节
    NRF24L01_WriteReg(NRF24L01_SETUP_RETR, 0x03);  // 自动重传延迟250us+86us，重传3次
    NRF24L01_WriteReg(NRF24L01_RF_CH,      0x02);  // 射频通道2
    NRF24L01_WriteReg(NRF24L01_RF_SETUP,   0x0E);  // 速率2Mbps，功率0dBm
    NRF24L01_WriteReg(NRF24L01_RX_PW_P0,   NRF24L01_RX_PACKET_WIDTH); // 接收通道0数据包宽度
    NRF24L01_WriteRegs(NRF24L01_RX_ADDR_P0, NRF24L01_RxAddress, 5);   // 设置接收地址

    NRF24L01_FlushTx();                     // 清空TX FIFO
    NRF24L01_FlushRx();                     // 清空RX FIFO
    NRF24L01_WriteReg(NRF24L01_STATUS, 0x70); // 清除状态位 (RX_DR|TX_DS|MAX_RT)

    NRF24L01_Rx();                          // 默认进入接收模式
}

/**
  * 函    数：发送数据包
  * 返 回 值：1-发送成功，2-达到最大重发次数，3-状态异常，4-超时
  */
uint8_t NRF24L01_Send(void)
{
    uint8_t  Status;
    uint8_t  SendFlag;
    uint32_t Timeout;

    /* 设置发送地址和通道0地址（用于接收应答）*/
    NRF24L01_WriteRegs(NRF24L01_TX_ADDR,    NRF24L01_TxAddress, 5);
    NRF24L01_WriteRegs(NRF24L01_RX_ADDR_P0, NRF24L01_TxAddress, 5);

    /* 写入待发送数据到TX FIFO */
    NRF24L01_WriteTxPayload(NRF24L01_TxPacket, NRF24L01_TX_PACKET_WIDTH);

    NRF24L01_Tx();                          // 切换到发送模式并启动发送

    /* 等待发送完成 */
    Timeout = 10000;
    while (1)
    {
        Status = NRF24L01_ReadStatus();
        Timeout--;
        if (Timeout == 0)
        {
            SendFlag = 4;                   // 超时
            NRF24L01_Init();
            break;
        }
        if ((Status & 0x30) == 0x30)        // TX_DS 和 MAX_RT 同时置位
        {
            SendFlag = 3;                   // 状态异常
            NRF24L01_Init();
            break;
        }
        else if ((Status & 0x10) == 0x10)   // MAX_RT 置位（达到最大重发次数）
        {
            SendFlag = 2;
            NRF24L01_Init();
            break;
        }
        else if ((Status & 0x20) == 0x20)   // TX_DS 置位（发送成功，收到应答）
        {
            SendFlag = 1;
            break;
        }
    }

    /* 清除发送中断标志，清空TX FIFO，恢复接收地址，切回接收模式 */
    NRF24L01_WriteReg(NRF24L01_STATUS, 0x30);
    NRF24L01_FlushTx();
    NRF24L01_WriteRegs(NRF24L01_RX_ADDR_P0, NRF24L01_RxAddress, 5);
    NRF24L01_Rx();

    return SendFlag;
}

/**
  * 函    数：接收数据包
  * 返 回 值：0-无数据，1-成功接收，2-状态异常，3-掉电模式异常
  */
uint8_t NRF24L01_Receive(void)
{
    uint8_t Status, Config;
    uint8_t ReceiveFlag;

    Status = NRF24L01_ReadStatus();
    Config = NRF24L01_ReadReg(NRF24L01_CONFIG);

    if ((Config & 0x02) == 0x00)            // 处于掉电模式 (PWR_UP=0)
    {
        ReceiveFlag = 3;
        NRF24L01_Init();
    }
    else if ((Status & 0x30) == 0x30)       // TX_DS 和 MAX_RT 同时置位（异常）
    {
        ReceiveFlag = 2;
        NRF24L01_Init();
    }
    else if ((Status & 0x40) == 0x40)       // RX_DR 置位（收到数据）
    {
        ReceiveFlag = 1;
        NRF24L01_ReadRxPayload(NRF24L01_RxPacket, NRF24L01_RX_PACKET_WIDTH);
        NRF24L01_WriteReg(NRF24L01_STATUS, 0x40);  // 清除RX_DR位
        NRF24L01_FlushRx();                         // 清空RX FIFO
    }
    else
    {
        ReceiveFlag = 0;                    // 无数据
    }

    return ReceiveFlag;
}

/**
  * 函    数：动态更新接收地址
  * 说    明：修改全局数组NRF24L01_RxAddress后调用此函数使新地址生效
  */
void NRF24L01_UpdateRxAddress(void)
{
    NRF24L01_WriteRegs(NRF24L01_RX_ADDR_P0, NRF24L01_RxAddress, 5);
}