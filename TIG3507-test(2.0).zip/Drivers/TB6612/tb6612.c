#include "tb6612.h"


void Motor1_SetSpeed(int16_t Speed)
{
	if(Speed>=0)
	{
       	DL_GPIO_setPins(tb6612_AIN2_PORT,tb6612_AIN2_PIN);
        DL_GPIO_clearPins(tb6612_AIN1_PORT,  tb6612_AIN1_PIN);
        DL_TimerA_setCaptureCompareValue(PWM_motorA_INST,Speed,GPIO_PWM_motorA_C1_IDX);
	}
	else
	{ 	
		DL_GPIO_setPins(tb6612_AIN1_PORT, tb6612_AIN1_PIN);
        DL_GPIO_clearPins(tb6612_AIN2_PORT, tb6612_AIN2_PIN);        
        DL_TimerA_setCaptureCompareValue(PWM_motorA_INST,-Speed,GPIO_PWM_motorA_C1_IDX);
	}
}

void Motor2_SetSpeed(int16_t Speed)
{
	if(Speed>=0)
	{
		DL_GPIO_setPins(tb6612_BIN2_PORT,tb6612_BIN2_PIN);
        DL_GPIO_clearPins(tb6612_BIN1_PORT,  tb6612_BIN1_PIN);
        DL_TimerA_setCaptureCompareValue(PWM_motorA_INST,Speed,GPIO_PWM_motorA_C0_IDX);
	}
	else
	{
		DL_GPIO_setPins(tb6612_BIN1_PORT, tb6612_BIN1_PIN);
        DL_GPIO_clearPins(tb6612_BIN2_PORT, tb6612_BIN2_PIN);
        DL_TimerA_setCaptureCompareValue(PWM_motorA_INST,-Speed,GPIO_PWM_motorA_C0_IDX);
	}
}

// 可选：统一控制两个电机的函数
void Motor_SetSpeed(int16_t Speed1, int16_t Speed2)
{
	Motor1_SetSpeed(Speed1);
	Motor2_SetSpeed(Speed2);
}