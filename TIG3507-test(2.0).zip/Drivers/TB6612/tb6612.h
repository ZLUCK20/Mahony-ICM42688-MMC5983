#ifndef _TB6612_H_
#define _TB6612_H_

#include "ti_msp_dl_config.h"
#include "main.h"

void Motor1_SetSpeed(int16_t Speed);
void Motor2_SetSpeed(int16_t Speed);
void Motor_SetSpeed(int16_t Speed1, int16_t Speed2);


#endif  /* #ifndef _CLOCK_H_ */