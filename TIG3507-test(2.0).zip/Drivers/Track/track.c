#include "ti_msp_dl_config.h"
#include "string.h"

int8_t track_error;

void Tracking_ReadAll_String(char *str)
{
    str[0] = (DL_GPIO_readPins(Track_PIN_0_PORT,Track_PIN_0_PIN) == 0) ? '0' : '1';
    str[1] = (DL_GPIO_readPins(Track_PIN_1_PORT,Track_PIN_1_PIN) == 0) ? '0' : '1';
    str[2] = (DL_GPIO_readPins(Track_PIN_2_PORT,Track_PIN_2_PIN) == 0) ? '0' : '1';
    str[3] = (DL_GPIO_readPins(Track_PIN_3_PORT,Track_PIN_3_PIN) == 0) ? '0' : '1';
    str[4] = (DL_GPIO_readPins(Track_PIN_4_PORT,Track_PIN_4_PIN) == 0) ? '0' : '1';
    str[5] = (DL_GPIO_readPins(Track_PIN_5_PORT,Track_PIN_5_PIN) == 0) ? '0' : '1';
    str[6] = (DL_GPIO_readPins(Track_PIN_6_PORT,Track_PIN_6_PIN) == 0) ? '0' : '1';
    str[7] = (DL_GPIO_readPins(Track_PIN_7_PORT,Track_PIN_7_PIN) == 0) ? '0' : '1';
    str[8] = '\0';
}

void Tracking_run(char *val)
{ 
	if (strcmp(val, "00011000") == 0)	
    {track_error=0;}
    
	//右偏				
    else if (strcmp(val, "00001000") == 0)
    { track_error=5;}

    else if (strcmp(val, "00001100") == 0)
    { track_error=7;}

    else if (strcmp(val, "00000100") == 0)
    { track_error=10;}

    else if (strcmp(val, "00000110") == 0)
    { track_error=12;}

    else if (strcmp(val, "00000010") == 0)
    { track_error=15;}

    else if (strcmp(val, "00000011") == 0)
    { track_error=17;}

    else if (strcmp(val, "00000001") == 0)
    { track_error=20;}

    //左偏					
    else if (strcmp(val, "00010000") == 0)
    { track_error=-5;}

    else if (strcmp(val, "00110000") == 0)
    { track_error=-7;}

    else if (strcmp(val, "00100000") == 0)
    { track_error=-10;}

    else if (strcmp(val, "01100000") == 0)
    { track_error=-12;}

    else if (strcmp(val, "01000000") == 0)
    { track_error=-15;}

    else if (strcmp(val, "11000000") == 0)
    { track_error=-17;}

    else if (strcmp(val, "10000000") == 0)
    { track_error=-20;}    
}
