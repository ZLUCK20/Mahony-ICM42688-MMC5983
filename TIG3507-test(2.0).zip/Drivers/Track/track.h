#ifndef _TRACK_H_
#define _TRACK_H_

#include "ti_msp_dl_config.h"
#include "main.h"

extern int8_t track_error;

void Tracking_ReadAll_String(char *str);
void Tracking_run(char *val);

#endif 
