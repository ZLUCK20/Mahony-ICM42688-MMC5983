#ifndef _STEPMOTOR_H_
#define _STEPMOTOR_H_

#include <stdint.h>

/* 步进电机参数：51200个脉冲转一圈 */
#define STEPMOTOR_PULSES_PER_REV  51200

void Stepmotor_Init(void);
void Stepmotor_Disable(void);
void Stepmotor_Enable(void);
void Stepmotor_Move(char ch, int32_t num);   // ch='x'或'y', 正数正转, 负数反转
void Stepmotor_StepX(void);
void Stepmotor_StepY(void);
void Stepmotor_DirX(uint8_t dir);            // 0左 1右
void Stepmotor_DirY(uint8_t dir);            // 0上 1下

#endif /* _STEPMOTOR_H_ */