/*
 * stepmotor.c - 步进电机驱动 (MSPM0G3507)
 *
 * 移植自STM32F407ZGT6版本，适配TI MSPM0 DriverLib
 *
 * 引脚定义 (SysConfig - GPIO7: stepmotor):
 *   EN1  -> PA24    (使能1, 高电平有效)
 *   STEP1 -> PA26   (脉冲1)
 *   DIR1 -> PA27    (方向1, 0左 1右)
 *   EN2  -> PA22    (使能2, 高电平有效)
 *   STEP2 -> PB24   (脉冲2)
 *   DIR2 -> PB25    (方向2, 0上 1下)
 *
 * 注：步进电机参数 51200个脉冲转一圈
 */

#include "stepmotor.h"
#include "ti_msp_dl_config.h"

/* ========== 微秒级延时 (软件循环，80MHz主频) ========== */
static inline void stepmotor_delay_us(uint32_t us)
{
    for (uint32_t i = 0; i < (us * 20); i++)
    {
        __NOP();
    }
}

/* ========== 步进电机初始化 ========== */
void Stepmotor_Init(void)
{
    DL_GPIO_setPins(stepmotor_EN1_PORT, stepmotor_EN1_PIN);
    DL_GPIO_setPins(stepmotor_EN2_PORT, stepmotor_EN2_PIN);
    DL_GPIO_clearPins(stepmotor_DIR1_PORT, stepmotor_DIR1_PIN);
    DL_GPIO_clearPins(stepmotor_DIR2_PORT, stepmotor_DIR2_PIN);
    DL_GPIO_clearPins(stepmotor_STEP1_PORT, stepmotor_STEP1_PIN);
    DL_GPIO_clearPins(stepmotor_STEP2_PORT, stepmotor_STEP2_PIN);
}

/* ========== 使能/失能 ========== */
void Stepmotor_Disable(void)
{
    DL_GPIO_clearPins(stepmotor_EN1_PORT, stepmotor_EN1_PIN);
    DL_GPIO_clearPins(stepmotor_EN2_PORT, stepmotor_EN2_PIN);
}

void Stepmotor_Enable(void)
{
    DL_GPIO_setPins(stepmotor_EN1_PORT, stepmotor_EN1_PIN);
    DL_GPIO_setPins(stepmotor_EN2_PORT, stepmotor_EN2_PIN);
}

/* ========== 单步脉冲 ========== */
void Stepmotor_StepX(void)
{
    DL_GPIO_setPins(stepmotor_STEP1_PORT, stepmotor_STEP1_PIN);
    stepmotor_delay_us(2);
    DL_GPIO_clearPins(stepmotor_STEP1_PORT, stepmotor_STEP1_PIN);
}

void Stepmotor_StepY(void)
{
    DL_GPIO_setPins(stepmotor_STEP2_PORT, stepmotor_STEP2_PIN);
    stepmotor_delay_us(2);
    DL_GPIO_clearPins(stepmotor_STEP2_PORT, stepmotor_STEP2_PIN);
}

/* ========== 方向控制 ========== */
void Stepmotor_DirX(uint8_t dir)
{
    if (dir)
        DL_GPIO_setPins(stepmotor_DIR1_PORT, stepmotor_DIR1_PIN);
    else
        DL_GPIO_clearPins(stepmotor_DIR1_PORT, stepmotor_DIR1_PIN);
}

void Stepmotor_DirY(uint8_t dir)
{
    if (dir)
        DL_GPIO_setPins(stepmotor_DIR2_PORT, stepmotor_DIR2_PIN);
    else
        DL_GPIO_clearPins(stepmotor_DIR2_PORT, stepmotor_DIR2_PIN);
}

/* ========== 多步脉冲（含方向自动设置） ========== */
void Stepmotor_Move(char ch, int32_t num)
{
    int32_t i;

    if (ch == 'x')
    {
        if (num > 0)
        {
            Stepmotor_DirX(0);
            for (i = num; i > 0; i--)
                Stepmotor_StepX();
        }
        else
        {
            Stepmotor_DirX(1);
            for (i = -num; i > 0; i--)
                Stepmotor_StepX();
        }
    }
    else
    {
        if (num > 0)
        {
            Stepmotor_DirY(0);
            for (i = num; i > 0; i--)
                Stepmotor_StepY();
        }
        else
        {
            Stepmotor_DirY(1);
            for (i = -num; i > 0; i--)
                Stepmotor_StepY();
        }
    }
}
