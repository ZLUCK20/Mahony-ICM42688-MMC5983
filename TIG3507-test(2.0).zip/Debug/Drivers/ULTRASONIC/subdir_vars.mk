################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/ULTRASONIC/ultrasonic.c 

C_DEPS += \
./Drivers/ULTRASONIC/ultrasonic.d 

OBJS += \
./Drivers/ULTRASONIC/ultrasonic.o 

OBJS__QUOTED += \
"Drivers\ULTRASONIC\ultrasonic.o" 

C_DEPS__QUOTED += \
"Drivers\ULTRASONIC\ultrasonic.d" 

C_SRCS__QUOTED += \
"../Drivers/ULTRASONIC/ultrasonic.c" 


