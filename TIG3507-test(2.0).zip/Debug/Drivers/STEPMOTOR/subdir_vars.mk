################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/STEPMOTOR/stepmotor.c 

C_DEPS += \
./Drivers/STEPMOTOR/stepmotor.d 

OBJS += \
./Drivers/STEPMOTOR/stepmotor.o 

OBJS__QUOTED += \
"Drivers\STEPMOTOR\stepmotor.o" 

C_DEPS__QUOTED += \
"Drivers\STEPMOTOR\stepmotor.d" 

C_SRCS__QUOTED += \
"../Drivers/STEPMOTOR/stepmotor.c" 


