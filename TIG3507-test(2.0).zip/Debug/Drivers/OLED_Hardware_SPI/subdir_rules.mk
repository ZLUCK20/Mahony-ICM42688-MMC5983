################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
Drivers/OLED_Hardware_SPI/%.o: ../Drivers/OLED_Hardware_SPI/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Arm Compiler - building file: "$<"'
	"D:/TI/CCS/ccs/tools/compiler/ti-cgt-armllvm_4.0.4.LTS/bin/tiarmclang.exe" -c @"device.opt"  -march=thumbv6m -mcpu=cortex-m0plus -mfloat-abi=soft -mlittle-endian -mthumb -O0 -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/LSM6DSV16X" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/VL53L0X" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/WIT" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/BNO08X_UART_RVC" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/Ultrasonic_GPIO" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/Ultrasonic_Capture" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/OLED_Hardware_I2C" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/OLED_Hardware_SPI" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/OLED_Software_I2C" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/OLED_Software_SPI" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/MPU6050" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Debug" -I"D:/TI/CCS/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"D:/TI/CCS/mspm0_sdk_2_10_00_04/source" -I"D:/TI_workspace_ccstheia/bno08x-uart-rvc-oled-hardware-spi/Drivers/MSPM0" -DMOTION_DRIVER_TARGET_MSPM0 -DMPU6050 -D__MSPM0G3507__ -gdwarf-3 -MMD -MP -MF"Drivers/OLED_Hardware_SPI/$(basename $(<F)).d_raw" -MT"$(@)"  $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


