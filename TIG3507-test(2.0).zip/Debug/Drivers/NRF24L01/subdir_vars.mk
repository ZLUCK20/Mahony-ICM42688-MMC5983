################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/NRF24L01/NRF24L01.c 

C_DEPS += \
./Drivers/NRF24L01/NRF24L01.d 

OBJS += \
./Drivers/NRF24L01/NRF24L01.o 

OBJS__QUOTED += \
"Drivers\NRF24L01\NRF24L01.o" 

C_DEPS__QUOTED += \
"Drivers\NRF24L01\NRF24L01.d" 

C_SRCS__QUOTED += \
"../Drivers/NRF24L01/NRF24L01.c" 


