################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/USART/usart.c 

C_DEPS += \
./Drivers/USART/usart.d 

OBJS += \
./Drivers/USART/usart.o 

OBJS__QUOTED += \
"Drivers\USART\usart.o" 

C_DEPS__QUOTED += \
"Drivers\USART\usart.d" 

C_SRCS__QUOTED += \
"../Drivers/USART/usart.c" 


