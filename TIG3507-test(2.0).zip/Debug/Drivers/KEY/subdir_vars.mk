################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/KEY/key_encoder.c 

C_DEPS += \
./Drivers/KEY/key_encoder.d 

OBJS += \
./Drivers/KEY/key_encoder.o 

OBJS__QUOTED += \
"Drivers\KEY\key_encoder.o" 

C_DEPS__QUOTED += \
"Drivers\KEY\key_encoder.d" 

C_SRCS__QUOTED += \
"../Drivers/KEY/key_encoder.c" 


