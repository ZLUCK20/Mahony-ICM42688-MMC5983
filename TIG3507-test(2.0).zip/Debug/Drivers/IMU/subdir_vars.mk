################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Drivers/IMU/MMC5983.c \
../Drivers/IMU/icm42688.c \
../Drivers/IMU/mahony_filter.c 

C_DEPS += \
./Drivers/IMU/MMC5983.d \
./Drivers/IMU/icm42688.d \
./Drivers/IMU/mahony_filter.d 

OBJS += \
./Drivers/IMU/MMC5983.o \
./Drivers/IMU/icm42688.o \
./Drivers/IMU/mahony_filter.o 

OBJS__QUOTED += \
"Drivers\IMU\MMC5983.o" \
"Drivers\IMU\icm42688.o" \
"Drivers\IMU\mahony_filter.o" 

C_DEPS__QUOTED += \
"Drivers\IMU\MMC5983.d" \
"Drivers\IMU\icm42688.d" \
"Drivers\IMU\mahony_filter.d" 

C_SRCS__QUOTED += \
"../Drivers/IMU/MMC5983.c" \
"../Drivers/IMU/icm42688.c" \
"../Drivers/IMU/mahony_filter.c" 


