/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     80000000
/* Defines for SYSPLL_ERR_01 Workaround */
/* Represent 1.000 as 1000 */
#define FLOAT_TO_INT_SCALE                                               (1000U)
#define FCC_EXPECTED_RATIO                                                  2500
#define FCC_UPPER_BOUND                       (FCC_EXPECTED_RATIO * (1 + 0.003))
#define FCC_LOWER_BOUND                       (FCC_EXPECTED_RATIO * (1 - 0.003))

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);


/* Defines for PWM_motorA */
#define PWM_motorA_INST                                                    TIMA0
#define PWM_motorA_INST_IRQHandler                              TIMA0_IRQHandler
#define PWM_motorA_INST_INT_IRQN                                (TIMA0_INT_IRQn)
#define PWM_motorA_INST_CLK_FREQ                                        10000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_motorA_C0_PORT                                            GPIOB
#define GPIO_PWM_motorA_C0_PIN                                     DL_GPIO_PIN_8
#define GPIO_PWM_motorA_C0_IOMUX                                 (IOMUX_PINCM25)
#define GPIO_PWM_motorA_C0_IOMUX_FUNC                IOMUX_PINCM25_PF_TIMA0_CCP0
#define GPIO_PWM_motorA_C0_IDX                               DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_motorA_C1_PORT                                            GPIOB
#define GPIO_PWM_motorA_C1_PIN                                     DL_GPIO_PIN_9
#define GPIO_PWM_motorA_C1_IOMUX                                 (IOMUX_PINCM26)
#define GPIO_PWM_motorA_C1_IOMUX_FUNC                IOMUX_PINCM26_PF_TIMA0_CCP1
#define GPIO_PWM_motorA_C1_IDX                               DL_TIMER_CC_1_INDEX

/* Defines for PWM_Servo */
#define PWM_Servo_INST                                                     TIMG7
#define PWM_Servo_INST_IRQHandler                               TIMG7_IRQHandler
#define PWM_Servo_INST_INT_IRQN                                 (TIMG7_INT_IRQn)
#define PWM_Servo_INST_CLK_FREQ                                          1000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_Servo_C0_PORT                                             GPIOA
#define GPIO_PWM_Servo_C0_PIN                                     DL_GPIO_PIN_26
#define GPIO_PWM_Servo_C0_IOMUX                                  (IOMUX_PINCM59)
#define GPIO_PWM_Servo_C0_IOMUX_FUNC                 IOMUX_PINCM59_PF_TIMG7_CCP0
#define GPIO_PWM_Servo_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_Servo_C1_PORT                                             GPIOA
#define GPIO_PWM_Servo_C1_PIN                                     DL_GPIO_PIN_27
#define GPIO_PWM_Servo_C1_IOMUX                                  (IOMUX_PINCM60)
#define GPIO_PWM_Servo_C1_IOMUX_FUNC                 IOMUX_PINCM60_PF_TIMG7_CCP1
#define GPIO_PWM_Servo_C1_IDX                                DL_TIMER_CC_1_INDEX

/* Defines for PWM_ULTRASONIC */
#define PWM_ULTRASONIC_INST                                               TIMG12
#define PWM_ULTRASONIC_INST_IRQHandler                         TIMG12_IRQHandler
#define PWM_ULTRASONIC_INST_INT_IRQN                           (TIMG12_INT_IRQn)
#define PWM_ULTRASONIC_INST_CLK_FREQ                                    80000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_ULTRASONIC_C0_PORT                                        GPIOA
#define GPIO_PWM_ULTRASONIC_C0_PIN                                DL_GPIO_PIN_14
#define GPIO_PWM_ULTRASONIC_C0_IOMUX                             (IOMUX_PINCM36)
#define GPIO_PWM_ULTRASONIC_C0_IOMUX_FUNC            IOMUX_PINCM36_PF_TIMG12_CCP0
#define GPIO_PWM_ULTRASONIC_C0_IDX                           DL_TIMER_CC_0_INDEX



/* Defines for CAPTURE_ULTRASONIC */
#define CAPTURE_ULTRASONIC_INST                                          (TIMG0)
#define CAPTURE_ULTRASONIC_INST_IRQHandler                        TIMG0_IRQHandler
#define CAPTURE_ULTRASONIC_INST_INT_IRQN                        (TIMG0_INT_IRQn)
#define CAPTURE_ULTRASONIC_INST_LOAD_VALUE                                (24999U)
/* GPIO defines for channel 0 */
#define GPIO_CAPTURE_ULTRASONIC_C0_PORT                                    GPIOB
#define GPIO_CAPTURE_ULTRASONIC_C0_PIN                            DL_GPIO_PIN_10
#define GPIO_CAPTURE_ULTRASONIC_C0_IOMUX                         (IOMUX_PINCM27)
#define GPIO_CAPTURE_ULTRASONIC_C0_IOMUX_FUNC             IOMUX_PINCM27_PF_TIMG0_CCP0





/* Defines for TIMER_Test */
#define TIMER_Test_INST                                                  (TIMA1)
#define TIMER_Test_INST_IRQHandler                              TIMA1_IRQHandler
#define TIMER_Test_INST_INT_IRQN                                (TIMA1_INT_IRQn)
#define TIMER_Test_INST_LOAD_VALUE                                       (3999U)




/* Defines for I2C_OLED */
#define I2C_OLED_INST                                                       I2C1
#define I2C_OLED_INST_IRQHandler                                 I2C1_IRQHandler
#define I2C_OLED_INST_INT_IRQN                                     I2C1_INT_IRQn
#define I2C_OLED_BUS_SPEED_HZ                                             400000
#define GPIO_I2C_OLED_SDA_PORT                                             GPIOA
#define GPIO_I2C_OLED_SDA_PIN                                     DL_GPIO_PIN_16
#define GPIO_I2C_OLED_IOMUX_SDA                                  (IOMUX_PINCM38)
#define GPIO_I2C_OLED_IOMUX_SDA_FUNC                   IOMUX_PINCM38_PF_I2C1_SDA
#define GPIO_I2C_OLED_SCL_PORT                                             GPIOA
#define GPIO_I2C_OLED_SCL_PIN                                     DL_GPIO_PIN_15
#define GPIO_I2C_OLED_IOMUX_SCL                                  (IOMUX_PINCM37)
#define GPIO_I2C_OLED_IOMUX_SCL_FUNC                   IOMUX_PINCM37_PF_I2C1_SCL


/* Defines for UART_3 */
#define UART_3_INST                                                        UART3
#define UART_3_INST_FREQUENCY                                           80000000
#define UART_3_INST_IRQHandler                                  UART3_IRQHandler
#define UART_3_INST_INT_IRQN                                      UART3_INT_IRQn
#define GPIO_UART_3_RX_PORT                                                GPIOB
#define GPIO_UART_3_TX_PORT                                                GPIOB
#define GPIO_UART_3_RX_PIN                                         DL_GPIO_PIN_3
#define GPIO_UART_3_TX_PIN                                         DL_GPIO_PIN_2
#define GPIO_UART_3_IOMUX_RX                                     (IOMUX_PINCM16)
#define GPIO_UART_3_IOMUX_TX                                     (IOMUX_PINCM15)
#define GPIO_UART_3_IOMUX_RX_FUNC                      IOMUX_PINCM16_PF_UART3_RX
#define GPIO_UART_3_IOMUX_TX_FUNC                      IOMUX_PINCM15_PF_UART3_TX
#define UART_3_BAUD_RATE                                                (115200)
#define UART_3_IBRD_80_MHZ_115200_BAUD                                      (43)
#define UART_3_FBRD_80_MHZ_115200_BAUD                                      (26)
/* Defines for UART_BNO08X */
#define UART_BNO08X_INST                                                   UART1
#define UART_BNO08X_INST_FREQUENCY                                      40000000
#define UART_BNO08X_INST_IRQHandler                             UART1_IRQHandler
#define UART_BNO08X_INST_INT_IRQN                                 UART1_INT_IRQn
#define GPIO_UART_BNO08X_RX_PORT                                           GPIOB
#define GPIO_UART_BNO08X_RX_PIN                                    DL_GPIO_PIN_5
#define GPIO_UART_BNO08X_IOMUX_RX                                (IOMUX_PINCM18)
#define GPIO_UART_BNO08X_IOMUX_RX_FUNC                 IOMUX_PINCM18_PF_UART1_RX
#define UART_BNO08X_BAUD_RATE                                           (115200)
#define UART_BNO08X_IBRD_40_MHZ_115200_BAUD                                 (21)
#define UART_BNO08X_FBRD_40_MHZ_115200_BAUD                                 (45)
/* Defines for UART_2 */
#define UART_2_INST                                                        UART2
#define UART_2_INST_FREQUENCY                                           40000000
#define UART_2_INST_IRQHandler                                  UART2_IRQHandler
#define UART_2_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_UART_2_RX_PORT                                                GPIOB
#define GPIO_UART_2_TX_PORT                                                GPIOB
#define GPIO_UART_2_RX_PIN                                        DL_GPIO_PIN_16
#define GPIO_UART_2_TX_PIN                                        DL_GPIO_PIN_15
#define GPIO_UART_2_IOMUX_RX                                     (IOMUX_PINCM33)
#define GPIO_UART_2_IOMUX_TX                                     (IOMUX_PINCM32)
#define GPIO_UART_2_IOMUX_RX_FUNC                      IOMUX_PINCM33_PF_UART2_RX
#define GPIO_UART_2_IOMUX_TX_FUNC                      IOMUX_PINCM32_PF_UART2_TX
#define UART_2_BAUD_RATE                                                (115200)
#define UART_2_IBRD_40_MHZ_115200_BAUD                                      (21)
#define UART_2_FBRD_40_MHZ_115200_BAUD                                      (45)




/* Defines for SPI_NRF24L01 */
#define SPI_NRF24L01_INST                                                  SPI0
#define SPI_NRF24L01_INST_IRQHandler                            SPI0_IRQHandler
#define SPI_NRF24L01_INST_INT_IRQN                                SPI0_INT_IRQn
#define GPIO_SPI_NRF24L01_PICO_PORT                                       GPIOA
#define GPIO_SPI_NRF24L01_PICO_PIN                                DL_GPIO_PIN_9
#define GPIO_SPI_NRF24L01_IOMUX_PICO                            (IOMUX_PINCM20)
#define GPIO_SPI_NRF24L01_IOMUX_PICO_FUNC            IOMUX_PINCM20_PF_SPI0_PICO
#define GPIO_SPI_NRF24L01_POCI_PORT                                       GPIOA
#define GPIO_SPI_NRF24L01_POCI_PIN                               DL_GPIO_PIN_10
#define GPIO_SPI_NRF24L01_IOMUX_POCI                            (IOMUX_PINCM21)
#define GPIO_SPI_NRF24L01_IOMUX_POCI_FUNC            IOMUX_PINCM21_PF_SPI0_POCI
/* GPIO configuration for SPI_NRF24L01 */
#define GPIO_SPI_NRF24L01_SCLK_PORT                                       GPIOA
#define GPIO_SPI_NRF24L01_SCLK_PIN                               DL_GPIO_PIN_11
#define GPIO_SPI_NRF24L01_IOMUX_SCLK                            (IOMUX_PINCM22)
#define GPIO_SPI_NRF24L01_IOMUX_SCLK_FUNC            IOMUX_PINCM22_PF_SPI0_SCLK
/* Defines for SPI_IMU */
#define SPI_IMU_INST                                                       SPI1
#define SPI_IMU_INST_IRQHandler                                 SPI1_IRQHandler
#define SPI_IMU_INST_INT_IRQN                                     SPI1_INT_IRQn
#define GPIO_SPI_IMU_PICO_PORT                                            GPIOA
#define GPIO_SPI_IMU_PICO_PIN                                    DL_GPIO_PIN_18
#define GPIO_SPI_IMU_IOMUX_PICO                                 (IOMUX_PINCM40)
#define GPIO_SPI_IMU_IOMUX_PICO_FUNC                 IOMUX_PINCM40_PF_SPI1_PICO
#define GPIO_SPI_IMU_POCI_PORT                                            GPIOB
#define GPIO_SPI_IMU_POCI_PIN                                    DL_GPIO_PIN_14
#define GPIO_SPI_IMU_IOMUX_POCI                                 (IOMUX_PINCM31)
#define GPIO_SPI_IMU_IOMUX_POCI_FUNC                 IOMUX_PINCM31_PF_SPI1_POCI
/* GPIO configuration for SPI_IMU */
#define GPIO_SPI_IMU_SCLK_PORT                                            GPIOA
#define GPIO_SPI_IMU_SCLK_PIN                                    DL_GPIO_PIN_17
#define GPIO_SPI_IMU_IOMUX_SCLK                                 (IOMUX_PINCM39)
#define GPIO_SPI_IMU_IOMUX_SCLK_FUNC                 IOMUX_PINCM39_PF_SPI1_SCLK



/* Defines for DMA_CH0 */
#define DMA_CH0_CHAN_ID                                                      (0)
#define UART_3_INST_DMA_TRIGGER                              (DMA_UART3_TX_TRIG)
/* Defines for DMA_BNO08X */
#define DMA_BNO08X_CHAN_ID                                                   (1)
#define UART_BNO08X_INST_DMA_TRIGGER                         (DMA_UART1_RX_TRIG)


/* Port definition for Pin Group Buzzer */
#define Buzzer_PORT                                                      (GPIOB)

/* Defines for Pin: GPIOB.22 with pinCMx 50 on package pin 21 */
#define Buzzer_Pin_PIN                                          (DL_GPIO_PIN_22)
#define Buzzer_Pin_IOMUX                                         (IOMUX_PINCM50)
/* Defines for AIN1: GPIOA.12 with pinCMx 34 on package pin 5 */
#define tb6612_AIN1_PORT                                                 (GPIOA)
#define tb6612_AIN1_PIN                                         (DL_GPIO_PIN_12)
#define tb6612_AIN1_IOMUX                                        (IOMUX_PINCM34)
/* Defines for AIN2: GPIOA.13 with pinCMx 35 on package pin 6 */
#define tb6612_AIN2_PORT                                                 (GPIOA)
#define tb6612_AIN2_PIN                                         (DL_GPIO_PIN_13)
#define tb6612_AIN2_IOMUX                                        (IOMUX_PINCM35)
/* Defines for BIN1: GPIOB.7 with pinCMx 24 on package pin 59 */
#define tb6612_BIN1_PORT                                                 (GPIOB)
#define tb6612_BIN1_PIN                                          (DL_GPIO_PIN_7)
#define tb6612_BIN1_IOMUX                                        (IOMUX_PINCM24)
/* Defines for BIN2: GPIOB.6 with pinCMx 23 on package pin 58 */
#define tb6612_BIN2_PORT                                                 (GPIOB)
#define tb6612_BIN2_PIN                                          (DL_GPIO_PIN_6)
#define tb6612_BIN2_IOMUX                                        (IOMUX_PINCM23)
/* Defines for SW5: GPIOB.27 with pinCMx 58 on package pin 29 */
#define Key_SW5_PORT                                                     (GPIOB)
// groups represented: ["Encoder","Key"]
// pins affected: ["A0","A1","SW5","SW4"]
#define GPIO_MULTIPLE_GPIOB_INT_IRQN                            (GPIOB_INT_IRQn)
#define GPIO_MULTIPLE_GPIOB_INT_IIDX            (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define Key_SW5_IIDX                                        (DL_GPIO_IIDX_DIO27)
#define Key_SW5_PIN                                             (DL_GPIO_PIN_27)
#define Key_SW5_IOMUX                                            (IOMUX_PINCM58)
/* Defines for SW6: GPIOA.29 with pinCMx 4 on package pin 36 */
#define Key_SW6_PORT                                                     (GPIOA)
// groups represented: ["Encoder","Key"]
// pins affected: ["B0","B1","SW6"]
#define GPIO_MULTIPLE_GPIOA_INT_IRQN                            (GPIOA_INT_IRQn)
#define GPIO_MULTIPLE_GPIOA_INT_IIDX            (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define Key_SW6_IIDX                                        (DL_GPIO_IIDX_DIO29)
#define Key_SW6_PIN                                             (DL_GPIO_PIN_29)
#define Key_SW6_IOMUX                                             (IOMUX_PINCM4)
/* Defines for SW4: GPIOB.21 with pinCMx 49 on package pin 20 */
#define Key_SW4_PORT                                                     (GPIOB)
#define Key_SW4_IIDX                                        (DL_GPIO_IIDX_DIO21)
#define Key_SW4_PIN                                             (DL_GPIO_PIN_21)
#define Key_SW4_IOMUX                                            (IOMUX_PINCM49)
/* Defines for A0: GPIOB.26 with pinCMx 57 on package pin 28 */
#define Encoder_A0_PORT                                                  (GPIOB)
#define Encoder_A0_IIDX                                     (DL_GPIO_IIDX_DIO26)
#define Encoder_A0_PIN                                          (DL_GPIO_PIN_26)
#define Encoder_A0_IOMUX                                         (IOMUX_PINCM57)
/* Defines for A1: GPIOB.23 with pinCMx 51 on package pin 22 */
#define Encoder_A1_PORT                                                  (GPIOB)
#define Encoder_A1_IIDX                                     (DL_GPIO_IIDX_DIO23)
#define Encoder_A1_PIN                                          (DL_GPIO_PIN_23)
#define Encoder_A1_IOMUX                                         (IOMUX_PINCM51)
/* Defines for B0: GPIOA.1 with pinCMx 2 on package pin 34 */
#define Encoder_B0_PORT                                                  (GPIOA)
#define Encoder_B0_IIDX                                      (DL_GPIO_IIDX_DIO1)
#define Encoder_B0_PIN                                           (DL_GPIO_PIN_1)
#define Encoder_B0_IOMUX                                          (IOMUX_PINCM2)
/* Defines for B1: GPIOA.0 with pinCMx 1 on package pin 33 */
#define Encoder_B1_PORT                                                  (GPIOA)
#define Encoder_B1_IIDX                                      (DL_GPIO_IIDX_DIO0)
#define Encoder_B1_PIN                                           (DL_GPIO_PIN_0)
#define Encoder_B1_IOMUX                                          (IOMUX_PINCM1)
/* Defines for CSN: GPIOB.12 with pinCMx 29 on package pin 64 */
#define GPIO_NRF24L01_CSN_PORT                                           (GPIOB)
#define GPIO_NRF24L01_CSN_PIN                                   (DL_GPIO_PIN_12)
#define GPIO_NRF24L01_CSN_IOMUX                                  (IOMUX_PINCM29)
/* Defines for CE: GPIOB.13 with pinCMx 30 on package pin 1 */
#define GPIO_NRF24L01_CE_PORT                                            (GPIOB)
#define GPIO_NRF24L01_CE_PIN                                    (DL_GPIO_PIN_13)
#define GPIO_NRF24L01_CE_IOMUX                                   (IOMUX_PINCM30)
/* Defines for IRQ: GPIOA.31 with pinCMx 6 on package pin 39 */
#define GPIO_NRF24L01_IRQ_PORT                                           (GPIOA)
#define GPIO_NRF24L01_IRQ_PIN                                   (DL_GPIO_PIN_31)
#define GPIO_NRF24L01_IRQ_IOMUX                                   (IOMUX_PINCM6)
/* Defines for PIN_0: GPIOB.25 with pinCMx 56 on package pin 27 */
#define Track_PIN_0_PORT                                                 (GPIOB)
#define Track_PIN_0_PIN                                         (DL_GPIO_PIN_25)
#define Track_PIN_0_IOMUX                                        (IOMUX_PINCM56)
/* Defines for PIN_1: GPIOA.22 with pinCMx 47 on package pin 18 */
#define Track_PIN_1_PORT                                                 (GPIOA)
#define Track_PIN_1_PIN                                         (DL_GPIO_PIN_22)
#define Track_PIN_1_IOMUX                                        (IOMUX_PINCM47)
/* Defines for PIN_2: GPIOB.20 with pinCMx 48 on package pin 19 */
#define Track_PIN_2_PORT                                                 (GPIOB)
#define Track_PIN_2_PIN                                         (DL_GPIO_PIN_20)
#define Track_PIN_2_IOMUX                                        (IOMUX_PINCM48)
/* Defines for PIN_3: GPIOB.18 with pinCMx 44 on package pin 15 */
#define Track_PIN_3_PORT                                                 (GPIOB)
#define Track_PIN_3_PIN                                         (DL_GPIO_PIN_18)
#define Track_PIN_3_IOMUX                                        (IOMUX_PINCM44)
/* Defines for PIN_4: GPIOB.17 with pinCMx 43 on package pin 14 */
#define Track_PIN_4_PORT                                                 (GPIOB)
#define Track_PIN_4_PIN                                         (DL_GPIO_PIN_17)
#define Track_PIN_4_IOMUX                                        (IOMUX_PINCM43)
/* Defines for PIN_5: GPIOB.19 with pinCMx 45 on package pin 16 */
#define Track_PIN_5_PORT                                                 (GPIOB)
#define Track_PIN_5_PIN                                         (DL_GPIO_PIN_19)
#define Track_PIN_5_IOMUX                                        (IOMUX_PINCM45)
/* Defines for PIN_6: GPIOA.23 with pinCMx 53 on package pin 24 */
#define Track_PIN_6_PORT                                                 (GPIOA)
#define Track_PIN_6_PIN                                         (DL_GPIO_PIN_23)
#define Track_PIN_6_IOMUX                                        (IOMUX_PINCM53)
/* Defines for PIN_7: GPIOA.2 with pinCMx 7 on package pin 42 */
#define Track_PIN_7_PORT                                                 (GPIOA)
#define Track_PIN_7_PIN                                          (DL_GPIO_PIN_2)
#define Track_PIN_7_IOMUX                                         (IOMUX_PINCM7)
/* Defines for CS1: GPIOB.11 with pinCMx 28 on package pin 63 */
#define GPIO_ICM42688_CS1_PORT                                           (GPIOB)
#define GPIO_ICM42688_CS1_PIN                                   (DL_GPIO_PIN_11)
#define GPIO_ICM42688_CS1_IOMUX                                  (IOMUX_PINCM28)
/* Defines for CS2: GPIOA.7 with pinCMx 14 on package pin 49 */
#define GPIO_ICM42688_CS2_PORT                                           (GPIOA)
#define GPIO_ICM42688_CS2_PIN                                    (DL_GPIO_PIN_7)
#define GPIO_ICM42688_CS2_IOMUX                                  (IOMUX_PINCM14)
/* Defines for EN1: GPIOA.28 with pinCMx 3 on package pin 35 */
#define stepmotor_EN1_PORT                                               (GPIOA)
#define stepmotor_EN1_PIN                                       (DL_GPIO_PIN_28)
#define stepmotor_EN1_IOMUX                                       (IOMUX_PINCM3)
/* Defines for STEP1: GPIOB.4 with pinCMx 17 on package pin 52 */
#define stepmotor_STEP1_PORT                                             (GPIOB)
#define stepmotor_STEP1_PIN                                      (DL_GPIO_PIN_4)
#define stepmotor_STEP1_IOMUX                                    (IOMUX_PINCM17)
/* Defines for DIR1: GPIOA.8 with pinCMx 19 on package pin 54 */
#define stepmotor_DIR1_PORT                                              (GPIOA)
#define stepmotor_DIR1_PIN                                       (DL_GPIO_PIN_8)
#define stepmotor_DIR1_IOMUX                                     (IOMUX_PINCM19)
/* Defines for EN2: GPIOB.24 with pinCMx 52 on package pin 23 */
#define stepmotor_EN2_PORT                                               (GPIOB)
#define stepmotor_EN2_PIN                                       (DL_GPIO_PIN_24)
#define stepmotor_EN2_IOMUX                                      (IOMUX_PINCM52)
/* Defines for STEP2: GPIOA.24 with pinCMx 54 on package pin 25 */
#define stepmotor_STEP2_PORT                                             (GPIOA)
#define stepmotor_STEP2_PIN                                     (DL_GPIO_PIN_24)
#define stepmotor_STEP2_IOMUX                                    (IOMUX_PINCM54)
/* Defines for DIR2: GPIOA.25 with pinCMx 55 on package pin 26 */
#define stepmotor_DIR2_PORT                                              (GPIOA)
#define stepmotor_DIR2_PIN                                      (DL_GPIO_PIN_25)
#define stepmotor_DIR2_IOMUX                                     (IOMUX_PINCM55)




/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);

bool SYSCFG_DL_SYSCTL_SYSPLL_init(void);
void SYSCFG_DL_PWM_motorA_init(void);
void SYSCFG_DL_PWM_Servo_init(void);
void SYSCFG_DL_PWM_ULTRASONIC_init(void);
void SYSCFG_DL_CAPTURE_ULTRASONIC_init(void);
void SYSCFG_DL_TIMER_Test_init(void);
void SYSCFG_DL_I2C_OLED_init(void);
void SYSCFG_DL_UART_3_init(void);
void SYSCFG_DL_UART_BNO08X_init(void);
void SYSCFG_DL_UART_2_init(void);
void SYSCFG_DL_SPI_NRF24L01_init(void);
void SYSCFG_DL_SPI_IMU_init(void);
void SYSCFG_DL_DMA_init(void);

void SYSCFG_DL_SYSTICK_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
